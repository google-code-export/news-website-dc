﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;

namespace STWaco.Website.Account
{
    public partial class ForgotPassword : BaseUI.BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Phục Hồi Mật Khẩu";

            if (!IsPostBack)
            {
                passwordRecovery.GeneralFailureText = string.Format(ErrorBar, "Không thành công. Vui lòng kiểm tra lại.");
                passwordRecovery.QuestionFailureText = string.Format(ErrorBar, "Câu trả lời không hợp lệ.");
                passwordRecovery.UserNameFailureText = string.Format(ErrorBar, "Không tìm thấy tài khoản.");
            }
        }

        protected void passwordRecovery_SendingMail(object sender, MailMessageEventArgs e)
        {
            var smtpSender = new SmtpClient("smtp.gmail.com", 587);
            smtpSender.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpSender.Credentials = new System.Net.NetworkCredential("info@soctrangwaco.vn", "stwaco");
            smtpSender.EnableSsl = true;
            smtpSender.Timeout = 10000;

            smtpSender.Send(e.Message);
            e.Cancel = true;
        }
    }
}