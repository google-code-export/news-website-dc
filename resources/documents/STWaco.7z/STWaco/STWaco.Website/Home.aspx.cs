﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website
{
    public partial class Home : BaseUI.BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Trang Chủ";
            
            if (!IsPostBack)
            {
                newsBox.Posts = _posts.ToList();

                this.LoadSlideShow();
            }
        }

        private void LoadSlideShow()
        {
            homeSlideShow.DataSource = _slides.OrderBy(p => p.DisplayOrder == null)
                .ThenBy(p => p.DisplayOrder).ToList();
            homeSlideShow.DataBind();
        }
    }
}