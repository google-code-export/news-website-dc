﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Secured
{
    public partial class Default : BaseUI.SecuredPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string redirectUrl = string.Empty;

                if (User.IsInRole("Quản trị hệ thống"))
                {
                    redirectUrl = HostName + "/bao-mat/quan-tri-he-thong.aspx";
                }
                else if (User.IsInRole("Thành viên nội bộ"))
                {
                    redirectUrl = HostName + "/bao-mat/thanh-vien-noi-bo.aspx";
                }
                else if (User.IsInRole("Công văn viên"))
                {
                    redirectUrl = HostName + "/bao-mat/cong-van-vien.aspx";
                }

                Response.Redirect(redirectUrl);
            }
        }
    }
}