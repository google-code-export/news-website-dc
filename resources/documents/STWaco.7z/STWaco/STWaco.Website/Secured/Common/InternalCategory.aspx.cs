﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Secured.Common
{
    public partial class InternalCategory : BaseUI.SecuredPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Danh Mục Tin Nội Bộ";
            
            if (!IsPostBack)
            {
                this.LoadPostList();
                this.LoadPostByMonthsList();
            }
        }

        private void LoadPostList()
        {
            string timescope = Request.QueryString["scope"];

            if (string.IsNullOrEmpty(timescope))
            {
                inList.Posts = _posts.Where(p => p.Category.Name.Trim().ToLower().Equals("thông tin nội bộ")).ToList();
            }
            else
            {
                int month = int.Parse(timescope.Split(' ')[0]);
                int year = int.Parse(timescope.Split(' ')[1]);

                inList.Posts = _posts.Where(p => p.Category.Name.Trim().ToLower().Equals("thông tin nội bộ")
                    && p.CreatedOn.Month == month && p.CreatedOn.Year == year).ToList();
            }

            inList.CategoryDir = "tin-noi-bo";
            inList.SecuredPreffix = "/bao-mat";
            inList.DataBind();
        }

        private void LoadPostByMonthsList()
        {
            _InternalNewsByMonths.Posts = _posts.ToList();
            _InternalNewsByMonths.DataBind();
        }
    }
}