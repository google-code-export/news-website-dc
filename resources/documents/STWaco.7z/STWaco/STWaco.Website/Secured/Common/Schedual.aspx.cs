﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data.SqlClient;
using Telerik.Web.UI;

namespace STWaco.Website.Secured.Common
{
    public partial class Schedual : BaseUI.SecuredPage
    {
        private void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Lịch Làm Việc";
            
            if (!Page.IsPostBack)
            {
                //EventsDataSource.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ts_stwaco_appConnectionString2"].ConnectionString;
                //RoomsDataSource.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ts_stwaco_appConnectionString2"].ConnectionString;
                //RoomsDataSource1.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ts_stwaco_appConnectionString2"].ConnectionString;

                ddlDeparment.Items.Clear();
                ddlDeparment.DataSource = RoomsDataSource1;
                ddlDeparment.DataValueField = "RoomID";
                ddlDeparment.DataTextField = "Name";
                ddlDeparment.DataBind();
                ddlDeparment.Items.Insert(0, new RadComboBoxItem("Tất Cả"));
                ddlDeparment.Items.FindItemByText("Tất Cả").Selected = true;
                //RoomsDataSource.SelectCommand = "SELECT * FROM Grouping_Rooms";
                UpdateScheduler();
            }

        }

        private void UpdateScheduler()
        {
            RadScheduler1.Rebind();
        }

        protected void ddlDeparment_SelectedIndexChanged(object o, RadComboBoxSelectedIndexChangedEventArgs e)
        {
            if (ddlDeparment.SelectedValue != "")
            {
                RoomsDataSource.SelectCommand = "SELECT * FROM Grouping_Rooms WHERE RoomID = '" + ddlDeparment.SelectedValue + "'";
                UpdateScheduler();
            }
            else
            {
                RoomsDataSource.SelectCommand = "SELECT * FROM Grouping_Rooms";
                UpdateScheduler();
            }

        }
    }
}