﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Secured.Common
{
    public partial class Internal : BaseUI.SecuredPage
    {
        private static int _postID = 0;

        private static string _postTitle;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.LoadPostItem();
                this.LoadOtherPosts();
                this.LoadPostByMonthsList();                
            }
            
            this.Title = SiteTitle + "Tin Nội Bộ :: " + STWaco.Core.SEO.StringUtils.ToTitleCase(_postTitle);
        }

        private void LoadPostItem()
        {
            int.TryParse(Request.QueryString["id"], out _postID);
            postItem.Post = _posts.FirstOrDefault(p => p.ID == _postID);
            postItem.DataBind();

            _postTitle = postItem.Post.Title;
        }

        private void LoadOtherPosts()
        {
            otherInternalBox.Posts = _posts.Where(p => p.ID != _postID
                && p.Category.Name.Trim().ToLower().Equals("thông tin nội bộ")).ToList();
            otherInternalBox.CategoryDir = "tin-noi-bo";
            otherInternalBox.SecuredPreffix = "/bao-mat";
            otherInternalBox.DataBind();
        }

        private void LoadPostByMonthsList()
        {
            _InternalNewsByMonths.Posts = _posts.ToList();
            _InternalNewsByMonths.DataBind();
        }
    }
}