﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.IO;
using TSHAK.Components;
using ICSharpCode.SharpZipLib.Zip;
using System.Collections;

namespace STWaco.Website.Secured.Common
{
    public partial class FileManager : BaseUI.SecuredPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Chia Sẻ Tài Liệu";
        }
    }
}