﻿$(function() {
    $(".sidemenu-bar li").hover(function() {
        $(this).find(".submenu").addClass("active");
    }, function() {
        $(this).find(".submenu").removeClass("active");
    });
    $(".sidemenu-bar li > a").css({ "border-bottom": "1px dashed #082a73", "text-transform": "uppercase" });
    $(".sidemenu-bar li > a").last().css({ "border": "none" });
    $(".sidemenu-bar li:has(.submenu) > a").css({ "background": "url('" + $("#hostName").val() + "/images/icons/arrow_16.png') no-repeat 172px 14px" });
    $(".sidemenu-bar li .submenu a:first-child").css({ "border": "none" });
    $(".sidemenu-bar .link.parent-active").parent("li").addClass("active");
});