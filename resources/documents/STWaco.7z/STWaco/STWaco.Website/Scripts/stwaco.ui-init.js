﻿/// <reference path="jquery-1.4.2-vsdoc.js" />

$(function() {

    $.fx.speeds._default = 100;

    var userAgent = navigator.userAgent.toLowerCase();

    // Figure out what browser is being used
    $.browser = {
        version: (userAgent.match(/.+(?:rv|it|ra|ie|me)[\/: ]([\d.]+)/) || [])[1],
        chrome: /chrome/.test(userAgent),
        safari: /webkit/.test(userAgent) && !/chrome/.test(userAgent),
        opera: /opera/.test(userAgent),
        msie: /msie/.test(userAgent) && !/opera/.test(userAgent),
        mozilla: /mozilla/.test(userAgent) && !/(compatible|webkit)/.test(userAgent)
    };

    //analog clock
    var path = $("#analog-clock-path").val();
    var flashvars = {
        clockSkin: path + "skin02.png",
        arrowSkin: '2',
        arrowColor: 'ffffff'
    };
    swfobject.embedSWF(
		path + 'devAnalogClock.swf', // path to the widget
		'analog-clock',
		'160', // width of the widget
		'160', // height of the widget
		'8',
		path + 'expressInstall.swf',
		flashvars,
		{ scale: 'noscale', wmode: 'transparent' }
	);

	//link
	$("a").not("[class^=button]").addClass("link");
});