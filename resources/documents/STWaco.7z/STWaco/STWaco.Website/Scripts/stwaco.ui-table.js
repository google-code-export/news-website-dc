﻿$(function () {
    if ($(".ui-table .pager").size() > 0) {
        
        var coreHtml = "";
        var frameHtml1 = "<div class=\"data-pager\"><span class=\"wrapper right\">";
        var frameHtml2 = "</span><div class=\"clear\"></div></div>";

        var tds = $(".ui-table .pager table td:has(a, span)");
        tds.each(function () {
            coreHtml += $(this).html();
        });

        var resultHtml = frameHtml1 + coreHtml + frameHtml2;

        $(".ui-table").after(resultHtml);
        $(".ui-table .pager").remove();
    }

    $(".ui-table .limited-width").ellipsis();
});