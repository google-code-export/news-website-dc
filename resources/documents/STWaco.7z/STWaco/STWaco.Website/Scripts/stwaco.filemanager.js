﻿function btnDeleteFile_Click() {
    a = window.confirm("Bạn muốn xóa file này ?");
    if (a) {
        return true;
    }
    else {
        return false;
    }
}
function btnDeleteFolder_Click() {
    a = window.confirm("Bạn muốn xóa thư mục này và những file nằm trong nó?");
    if (a) {
        return true;
    }
    else {
        return false;
    }
}
function confirm_delete() {
    if (confirm("Bạn muốn xóa mục này?") == true)
        return true;
    else
        return false;
}
function btnDeleteCheckedItems_Click() {
    if (confirm("Bạn muốn xóa những mục chọn?") == true)
        return true;
    else
        return false;
}