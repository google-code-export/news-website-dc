﻿$(function() {
    //menu
    $(".mainmenu-bar li").hover(function() {
        $(this).find(".submenu").addClass("active");
    }, function() {
        $(this).find(".submenu").removeClass("active");
    });
    $(".mainmenu-bar li .submenu").hover(function() {
        $(this).parent("li").addClass("active");
    }, function() {
        $(this).parent("li:not(:has(.parent-active))").removeClass("active");
    });
    $(".mainmenu-bar li .submenu a:first-child").css({ "border": "none" });
    $(".mainmenu-bar .link.parent-active").parent("li").addClass("active");
});