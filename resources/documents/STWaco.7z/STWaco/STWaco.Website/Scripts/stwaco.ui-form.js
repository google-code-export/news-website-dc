﻿/// <reference path="jquery-1.4.2-vsdoc.js" />

$(function () {
    //text input
    $(":text,:password,textarea").addClass("textbox ui-corner-all");

    //button
    $(":button, .button").button();
    $(".button-login").button({
        icons: {
            primary: "ui-icon-key"
        }
    });
    $(".button-add").button({
        icons: {
            primary: "ui-icon-circle-plus"
        }
    });
    $(".button-update").button({
        icons: {
            primary: "ui-icon-circle-check"
        }
    });
    $(".button-search").button({
        icons: {
            primary: "ui-icon-search"
        }
    });
    $(".button-send").button({
        icons: {
            primary: "ui-icon-mail-closed"
        }
    });

    //browser suggestor
    if ($.browser.msie && $.browser.version <= 7) {
        $("#browser-suggestor").show();
        $("#browser-suggestor").dialog({
            show: "bounce",
            hide: "drop",
            width: "auto",
            resizable: false,
            modal: true
        });
    }

    //pager
    $(".data-pager > span").addClass("wrapper right");

    //over-flow holder
    /*$(".overflow-holder").height(function () {
        return $(this).find(".table-container").height();
    });

    $(".overflow-holder").hover(function () {
        var child = $(this).find(".table-container");
        $(this).css({ "overflow": "visible" });
        if (child.find(".ui-table").hasClass("narrow")) {
            child.css({ "left": -((child.width() - $(this).width()) / 2) });
        }
        else {
            child.css({ "left": -(child.width() - $(this).width()) });
        }
        child.find(".data-pager").width(child.width());
    },
    function () {
        var child = $(this).find(".table-container");
        $(this).css({ "overflow": "hidden" });
        child.css({ "left": 0 });
        if (child.find(".ui-table").hasClass("narrow")) {
            child.find(".data-pager").width(480);
        }
        else {
            child.find(".data-pager").width(720);
        }
    });*/

    //dropdown
    $(".html-editor select").addClass("ignored");
    $("select:not(.ignored)").selectmenu({ width: "27em" });
    $("select:not(.ignored)").next(".ui-selectmenu").addClass("select");
    $("select:not(.ignored)").next(".ui-selectmenu").find(".ui-selectmenu-status").addClass("select-item");

    //datepicker
    $(".datepicker").datepicker({
        showOn: "button",
        buttonImage: $("#hostName").val() + "/images/icons/calendar_24.png",
        buttonImageOnly: true
    }, $.datepicker.regional["vi"]);

    //table
    $(".ui-table tr").hover(function () {
        $(this).addClass("hover");
    },
    function () {
        $(this).removeClass("hover");
    });
});