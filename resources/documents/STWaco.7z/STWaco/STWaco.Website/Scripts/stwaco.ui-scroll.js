﻿$(function () {
    var sideCnt = $(".sideContent");
    var subCnt = $(".subContent");
    var mainCnt = $(".mainContent");

    if (sideCnt.height() < mainCnt.height()) {
        sideCnt.height(mainCnt.height());
    }
    if (subCnt.height() < mainCnt.height()) {
        subCnt.height(mainCnt.height());
    }

    var sideMovable = sideCnt.find(".movable");
    var subMovable = subCnt.find(".movable");

    var accountBar = $("#account_loggedin");

    scrollPanel(sideCnt, sideMovable, subCnt, subMovable, accountBar);

    $(window).scroll(function () {
        scrollPanel(sideCnt, sideMovable, subCnt, subMovable, accountBar);
    });
});

function scrollPanel(sideCnt, sideMovable, subCnt, subMovable, accountBar) {
    
    var fixedHeaderOffset = 160;
    var fixedFooterOffset = 160;

    if (accountBar.size() > 0) {
        fixedHeaderOffset = 200;
        fixedFooterOffset = 200;
    }

    var scrollTo = $(window).scrollTop()
    var calculatedSideMaxTop = $("#footer").offset().top - sideMovable.height() - fixedFooterOffset;
    var calculatedSubMaxTop = $("#footer").offset().top - subMovable.height() - fixedFooterOffset;

    if (scrollTo > calculatedSideMaxTop) {
        scrollTo = calculatedSideMaxTop;
    }
    if (scrollTo > calculatedSubMaxTop) {
        scrollTo = calculatedSubMaxTop;
    }
    else if (scrollTo < fixedHeaderOffset) {
        scrollTo = 0;
    }
    else {
        scrollTo -= fixedHeaderOffset;
    }

    if (sideCnt.height() - sideMovable.height() >= 200) {
        sideMovable.animate(
                { top: scrollTo + 'px' },
                { queue: false, duration: 500, easing: 'swing' }
            );
    }
    if (subCnt.height() - subMovable.height() >= 200) {
        subMovable.animate(
                { top: scrollTo + 'px' },
                { queue: false, duration: 500, easing: 'swing' }
            );
    }
}