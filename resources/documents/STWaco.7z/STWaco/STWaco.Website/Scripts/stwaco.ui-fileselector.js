﻿var prm = Sys.WebForms.PageRequestManager.getInstance();
prm.add_pageLoaded(panelLoaded);

function panelLoaded(sender, args) {    
    $(".button").button();
    $(".data-pager > span").addClass("wrapper right");

    initSelector();
}

$(function () {
    var mainCnt = $(".mainContent");
    var mainMovable = mainCnt.find(".movable");

    scrollPanel(mainCnt, mainMovable);

    $(window).scroll(function () {
        scrollPanel(mainCnt, mainMovable);
    });

    $(".dialog").dialog({
        autoOpen: false,
        width: "auto",
        resizable: false,
        modal: true,
		open: function(event, ui){
			$("input[id$=Insert]").hide();
		},
		close: function(event, ui){
			$("input[id$=Insert]").show();
		}
    });

    $("#selectButton").click(function () {
        $("#selectDialog").dialog("open");
    });
});

function initSelector() {    

    $(".fileItem").hover(function () {
        $(this).find(".button-delete").toggle();
        $(this).find(".button-copy").toggle();
    });

    $(".fileItem .button-delete").button({
        icons: {
            primary: "ui-icon-trash"
        },
        text: false
    });

    $(".fileItem .button-copy").button({
        icons: {
            primary: "ui-icon-copy"
        },
        text: false
    });

    /*$(".fileItem .button-copy").each(function () {
        $(this).zclip({
            path: $("#hostName").val() + "/media/ZeroClipboard.swf",
            copy: $(this).attr("title")
        });
    });*/

    if ($("#selectDialog").dialog("isOpen")) {
        $("input[id$=Insert]").hide();
    }
}

function scrollPanel(mainCnt, mainMovable) {
    fixedHeaderOffset = 190;
    fixedFooterOffset = 255;

    var scrollTo = $(window).scrollTop()
    var calculatedMainMaxTop = $("#footer").offset().top - mainMovable.height() - fixedFooterOffset;

    if (scrollTo > calculatedMainMaxTop) {
        scrollTo = calculatedMainMaxTop;
    }
    else if (scrollTo < fixedHeaderOffset) {
        scrollTo = 25;
    }
    else {
        scrollTo -= fixedHeaderOffset;
    }

    if (mainCnt.height() - mainMovable.height() >= 200) {
        mainMovable.animate(
            { top: scrollTo + 'px' },
            { queue: false, duration: 250, easing: 'swing' }
        );
    }
}