﻿/// <reference path="jquery-1.4.2-vsdoc.js" />

$(function () {
    refinePageControls();        
});

function refinePageControls() {
    $(":text, :password, :file").addClass("textbox");
    $(":checkbox").addClass("checkbox");
    $(":radio").addClass("radio");
    $(":button").addClass("button");
    $(":checkbox").next("label").addClass("chklabel");
}

function refineCategoryBrowser() {
    $("div[id^=cate_section] > span:last-child").addClass("cate_navigation");
    $("span.cate_navigation:not(:has(a.learn_more))").html(function (i, html) {
        return "Trang: " + html;
    });
}

function refineCategoryBrowser() {
    $("div[id^=cate_section] > span:last-child").addClass("cate_navigation");
    $("span.cate_navigation:not(:has(a.learn_more))").html(function (i, html) {
        return "Trang: " + html;
    });
}

function refinePostBrowser() {
    $(".posts_list > span[id$=pagerPosts]").html(function (i, html) {
        return "Trang: " + html;
    });
}

function refineCommentBox() {
    $("#comments_list").next("span[id$=pagerComments]").addClass("comment_navigation");
    $(".comment_navigation").html(function (i, html) {
        return "Trang: " + html;
    });
    if ($(".comment_navigation a").size() == 0)
        $(".comment_navigation").hide();
    else
        $(".comment_navigation").show();
}

function refineAdminList() {
    $(".datatable .pager table td:first").before("<td><span>Trang:</span></td>");
}

function refineFakeIdTabs() {
    if ($("ul.fakeIdTabs").size() > 0) {
        $("ul.fakeIdTabs").idTabs();
    }
}

function refineOverflowHolder() {
    $(".overflow_holder").height(function () {
        return $(this).find(".datatable, img").height() + 5;
    });

    $(".overflow_holder").each(function () {
        var child = $(this).find(".datatable, img");
        if ($(this).width() > child.width())
            child.css({ "left": (($(this).width() - child.width()) / 2) });
    });

    $(".overflow_holder").hover(function () {
        var child = $(this).find(".datatable, img");
        $(this).css({ "overflow": "visible" });
        if ($(this).width() < child.width())
            child.css({ "left": -((child.width() - $(this).width()) / 2) });
    },
    function () {
        var child = $(this).find(".datatable, img");
        $(this).css({ "overflow": "hidden" });
        if ($(this).width() < child.width())
            child.css({ "left": 0 });
        else
            child.css({ "left": (($(this).width() - child.width()) / 2) });
    });
}

function load() {
    Sys.WebForms.PageRequestManager.getInstance().add_endRequest(refinePageControls);
    Sys.WebForms.PageRequestManager.getInstance().add_endRequest(refineCategoryBrowser);
    Sys.WebForms.PageRequestManager.getInstance().add_endRequest(refineCommentBox);
}

function adminLoad() {
    Sys.WebForms.PageRequestManager.getInstance().add_endRequest(refinePageControls);
    Sys.WebForms.PageRequestManager.getInstance().add_endRequest(refineAdminList);
    Sys.WebForms.PageRequestManager.getInstance().add_endRequest(refineFakeIdTabs);
    Sys.WebForms.PageRequestManager.getInstance().add_endRequest(refineOverflowHolder);
}