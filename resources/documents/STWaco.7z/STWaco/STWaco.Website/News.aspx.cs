﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website
{
    public partial class News : BaseUI.BasePage
    {
        private static int _postID = 0;

        private static string _postTitle;

        protected void Page_Load(object sender, EventArgs e)
        {                       
            if (!IsPostBack)
            {                               
                this.LoadPostItem();
                this.LoadCommentBox();
                this.LoadOtherPosts();                
            }

            this.Title = SiteTitle + "Tin Tức :: " + STWaco.Core.SEO.StringUtils.ToTitleCase(_postTitle);
        }

        private void LoadPostItem()
        {
            int.TryParse(Request.QueryString["id"], out _postID);
            postItem.Post = _posts.FirstOrDefault(p => p.ID == _postID);
            postItem.DataBind();

            _postTitle = postItem.Post.Title;
        }

        private void LoadCommentBox()
        {
            int.TryParse(Request.QueryString["id"], out _postID);
            commentBox.PostItem = _posts.FirstOrDefault(p => p.ID == _postID);
            commentBox.DataBind();
        }

        private void LoadOtherPosts()
        {
            otherNewsBox.Posts = _posts.Where(p => p.ID != _postID
                && p.Category.Name.Trim().ToLower().Equals("tin tức")).ToList();
            otherNewsBox.CategoryDir = "tin-tuc";
            otherNewsBox.DataBind();
        }
    }
}