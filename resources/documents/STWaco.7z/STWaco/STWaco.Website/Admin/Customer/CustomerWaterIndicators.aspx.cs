﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace STWaco.Website.Admin.Customer
{
    public partial class CustomerWaterIndicators : BaseUI.AdminPage
    {
        private static Data.Customer _cus;
        private int year, month;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Quản Lý Chỉ Số Nước";

            if (!IsPostBack)
            {                
                this.LoadWaterCumsumptionList();
                BindDateTime();
            }
        }

        protected void BindDateTime()
        {
            DateTime tnow = DateTime.Now;
            ArrayList AlYear = new ArrayList();
            int i;
            for (i = 2008; i <= 2050; i++)
                AlYear.Add(i);
            ArrayList AlMonth = new ArrayList();
            for (i = 1; i <= 12; i++)
                AlMonth.Add(i);
            ddlYear.DataSource = AlYear;
            ddlYear.DataBind();
            ddlYear.SelectedValue = tnow.Year.ToString();
            ddlMonth.DataSource = AlMonth;
            ddlMonth.DataBind();
            ddlMonth.SelectedValue = tnow.Month.ToString();
            year = int.Parse(ddlYear.SelectedValue);
            month = int.Parse(ddlMonth.SelectedValue);
        }

        protected void grvWaterIndicators_SelectedIndexChanged(object sender, EventArgs e)
        {
            var waterconsumpId = int.Parse(grvWaterIndicators.SelectedDataKey["WaterConsumptionId"].ToString());
            var waterconsump = _waterconsump.FirstOrDefault(t => t.WaterConsumptionId == waterconsumpId);

            txtID.Text = waterconsump.Customer.ID;
            txtOldIndicator.Text = waterconsump.OldIndicator.ToString();
            txtNewIndicator.Text = waterconsump.NewIndicator.ToString();
            txtAmount.Text = waterconsump.Amount.ToString();
            ddlMonth.SelectedValue = waterconsump.Date.Month.ToString();
            ddlYear.SelectedValue = waterconsump.Date.Year.ToString();
            chkDeleted.Checked = waterconsump.Deleted;

            this.SetError(null);
        }

        protected void grvWaterIndicators_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvWaterIndicators.PageIndex = e.NewPageIndex;
        }

        protected void grvWaterIndicators_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadWaterCumsumptionList();
        }

        protected void grvWaterIndicators_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var waterconsumpId = int.Parse(grvWaterIndicators.DataKeys[e.RowIndex]["WaterConsumptionId"].ToString());
            var waterconsump = _waterconsump.FirstOrDefault(t => t.WaterConsumptionId == waterconsumpId);

            ApplicationManager.Entities.DeleteObject(waterconsump);
                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadWaterCumsumptionList();
                this.SetError(null);
                //if (!string.IsNullOrEmpty(txtID.Text) && waterconsumpId == txtID.Text)
                    this.ClearForm();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                string _cusId = txtID.Text.Trim();
                _cus = _cust.FirstOrDefault(p => p.ID == _cusId);
                year = int.Parse(ddlYear.SelectedValue);
                month = int.Parse(ddlMonth.SelectedValue);
                var waterconsump = new Data.WaterComsumption
                {
                    OldIndicator = float.Parse(txtOldIndicator.Text.Trim()),
                    NewIndicator = float.Parse(txtNewIndicator.Text.Trim()),
                    Consumption = float.Parse(txtNewIndicator.Text.Trim()) - float.Parse(txtOldIndicator.Text.Trim()),
                    Amount=float.Parse(txtAmount.Text.Trim()),
                    Date = Convert.ToDateTime(month + "/" + "01" + "/" + year),
                    Deleted = chkDeleted.Checked,
                    CreatedOn = DateTime.Now,
                    Customer = _cus,
                };

                ApplicationManager.Entities.AddToWaterComsumptions(waterconsump);
                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadWaterCumsumptionList();
                this.ClearForm();
            }
            catch (Exception)
            {
                this.SetError("Không thể thêm dữ liệu này.");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                string _cusId = txtID.Text.Trim();
                _cus = _cust.FirstOrDefault(p => p.ID == _cusId);

                year = int.Parse(ddlYear.SelectedValue);
                month = int.Parse(ddlMonth.SelectedValue);

                var waterconsumpId = int.Parse(grvWaterIndicators.SelectedDataKey["WaterConsumptionId"].ToString());
                var waterconsump = _waterconsump.FirstOrDefault(t => t.WaterConsumptionId == waterconsumpId);

                waterconsump.Customer = _cus;
                waterconsump.OldIndicator = float.Parse(txtOldIndicator.Text.Trim());
                waterconsump.NewIndicator = float.Parse(txtNewIndicator.Text.Trim());
                waterconsump.Consumption = float.Parse(txtNewIndicator.Text.Trim()) - float.Parse(txtOldIndicator.Text.Trim());
                waterconsump.Amount = float.Parse(txtAmount.Text.Trim());
                waterconsump.Date = Convert.ToDateTime(month + "/" + "01" + "/" + year);
                waterconsump.Deleted = chkDeleted.Checked;
                waterconsump.UpdatedOn = DateTime.Now;
                ApplicationManager.Entities.SaveChanges();
                this.UpdateCacheData();
                this.LoadWaterCumsumptionList();
                this.ClearForm();
                
            }
            catch (Exception)
            {
                this.SetError("Không thể cập nhật dữ liệu này.");
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearForm();
        }

        private void LoadWaterCumsumptionList()
        {
            grvWaterIndicators.DataSource = _waterconsump.OrderByDescending(t => t.CreatedOn).ToList();
            grvWaterIndicators.DataBind();
        }

        protected void grvWaterIndicators_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var waterconsump = e.Row.DataItem as Data.WaterComsumption;

                var ltCusId = e.Row.Cells[0].FindControl("ltCusId") as Literal;

                ltCusId.Text = waterconsump.Customer.ID;
            }
        }

        private void UpdateCacheData()
        {
            ApplicationManager.UpdateCacheData<Data.WaterComsumption>(ApplicationManager.Entities.WaterComsumptions.Where(t => !t.Deleted));
            _waterconsump = ApplicationManager.UpdateCacheData<Data.WaterComsumption>(ApplicationManager.Entities.WaterComsumptions, "AdminList");
        }

        private void ClearForm()
        {
            txtID.Text = string.Empty;
            txtOldIndicator.Text = string.Empty;
            txtNewIndicator.Text = string.Empty;
            txtAmount.Text = string.Empty;
            chkDeleted.Checked = false;
            ltrError.Text = string.Empty;
            txtID.Focus();
        }

        private void SetError(string message)
        {
            message = string.IsNullOrEmpty(message) ? null : string.Format(ErrorBar, message);
            ltrError.Text = message;
        }
    }
}