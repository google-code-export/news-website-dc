﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Admin.Customer
{
    public partial class CustomerManagement : BaseUI.AdminPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Thông Tin Khách Hàng";
            
            if (!IsPostBack)
            {                
                this.LoadCustomerList();
            }
        }

        protected void grvCustomers_SelectedIndexChanged(object sender, EventArgs e)
        {
            var cusID = grvCustomers.SelectedDataKey["ID"].ToString();
            var custom = _cust.FirstOrDefault(t => t.ID == cusID);

            txtID.Text = custom.ID;
            txtName.Text = custom.Name;
            txtAddress.Text = custom.Address;
            chkDeleted.Checked = custom.Deleted;

            this.SetError(null);
        }

        protected void grvCustomers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvCustomers.PageIndex = e.NewPageIndex;
        }

        protected void grvCustomers_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadCustomerList();
        }

        protected void grvCustomers_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var cusID = grvCustomers.DataKeys[e.RowIndex]["ID"].ToString();
            var custom = _cust.FirstOrDefault(t => t.ID == cusID);

            if (custom.WaterComsumptions.Count == 0)
            {
                ApplicationManager.Entities.DeleteObject(custom);
                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadCustomerList();
                this.SetError(null);
                if (!string.IsNullOrEmpty(txtID.Text) && cusID == txtID.Text)
                    this.ClearForm();
            }
            else
            {
                this.SetError("Danh bộ này đang sử dụng.");
                e.Cancel = true;
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                var custome = new Data.Customer
                {
                    ID=txtID.Text.Trim(),
                    Name = txtName.Text.Trim(),
                    Address = txtAddress.Text.Trim(),
                    Deleted = chkDeleted.Checked,
                    CreatedOn = DateTime.Now
                };

                ApplicationManager.Entities.AddToCustomers(custome);
                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadCustomerList();
                this.ClearForm();
            }
            catch (Exception ex)
            {
                this.SetError(ex.Message);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                var custom = _cust.FirstOrDefault(t => t.ID == txtID.Text);
                
                if (custom != null)
                {                    
                    custom.Name = txtName.Text.Trim();
                    custom.Address = txtAddress.Text.Trim();
                    custom.Deleted = chkDeleted.Checked;
                    custom.UpdatedOn = DateTime.Now;
                    ApplicationManager.Entities.SaveChanges();

                    this.UpdateCacheData();
                    this.LoadCustomerList();
                    this.ClearForm();
                }
                else
                {
                    this.SetError("Không tìm thấy danh bộ này.");
                }
            }
            catch (Exception ex)
            {
                this.SetError(ex.Message);
            }
        }

        private void LoadCustomerList()
        {
            grvCustomers.DataSource = _cust.OrderByDescending(t => t.CreatedOn).ToList();
            grvCustomers.DataBind();
        }

        private void UpdateCacheData()
        {
            ApplicationManager.UpdateCacheData<Data.Customer>(ApplicationManager.Entities.Customers.Where(t => !t.Deleted));
            _cust = ApplicationManager.UpdateCacheData<Data.Customer>(ApplicationManager.Entities.Customers, "AdminList");
        }

        private void ClearForm()
        {
            txtID.Text = string.Empty;
            txtName.Text = string.Empty;
            txtAddress.Text = string.Empty;
            chkDeleted.Checked = false;
            ltrError.Text = string.Empty;
            txtID.Focus();
        }

        private void SetError(string message)
        {
            message = string.IsNullOrEmpty(message) ? null : string.Format(ErrorBar, message);
            ltrError.Text = message;
        }
    }
}