﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace STWaco.Website.Admin.Photo
{
    public partial class Slide : BaseUI.AdminPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.Title = SiteTitle + "Cập Nhật SlideShow Trang Chủ";

                this.LoadSlidesList();
                this.LoadSlideShow();
                this.GenerateDisplayOrderList();
            }
        }

        protected void grvSlides_SelectedIndexChanged(object sender, EventArgs e)
        {
            int slideID = int.Parse(grvSlides.SelectedDataKey["ID"].ToString());
            var slide = _slides.FirstOrDefault(s => s.ID == slideID);

            txtID.Text = slideID.ToString();
            txtPhotoUrl.Text = slide.Photo;
            txtLink.Text = slide.Link;
            txtDescription.Text = slide.Description;

            if (slide.DisplayOrder.HasValue)
            {
                this.GenerateDisplayOrderList(new Data.ListOption
                {
                    Value = slide.DisplayOrder.Value,
                    Text = string.Format("Vị trí {0}", slide.DisplayOrder.Value)
                });
            }

            ddlDisplayOrder.Text = slide.DisplayOrder.ToString();           

            this.SetError(null);
        }

        protected void grvSlides_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var slide = e.Row.DataItem as Data.Slide;
                var lnkPhoto = e.Row.Cells[3].FindControl("lnkPhoto") as HyperLink;

                lnkPhoto.NavigateUrl = slide.Photo;
                lnkPhoto.Text = Path.GetFileName(slide.Photo);
            }
        }

        protected void grvSlides_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvSlides.PageIndex = e.NewPageIndex;
        }

        protected void grvSlides_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadSlidesList();
        }

        protected void grvSlides_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int slideID = int.Parse(grvSlides.DataKeys[e.RowIndex]["ID"].ToString());
            var slide = _slides.FirstOrDefault(s => s.ID == slideID);

            ApplicationManager.Entities.DeleteObject(slide);
            ApplicationManager.Entities.SaveChanges();

            this.UpdateCacheData();
            this.LoadSlidesList();
            this.LoadSlideShow();
            this.GenerateDisplayOrderList();

            if (!string.IsNullOrEmpty(txtID.Text) && slideID == int.Parse(txtID.Text))
                this.ClearForm();
            else
                SetError(null);
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            int? displayOrder = null;
            if (!string.IsNullOrEmpty(ddlDisplayOrder.SelectedValue))
            {
                displayOrder = int.Parse(ddlDisplayOrder.SelectedValue);
            }

            var usedPositions = _slides.Where(s => s.DisplayOrder != null).Select(s => s.DisplayOrder);

            if (!usedPositions.Contains(displayOrder))
            {
                var slide = new Data.Slide
                {
                    Photo = txtPhotoUrl.Text,
                    Link = string.IsNullOrEmpty(txtLink.Text.Trim()) ? HostName + "/trang-chu.aspx" : txtLink.Text.Trim(),
                    Description = txtDescription.Text.Trim(),
                    DisplayOrder = displayOrder,
                    CreatedOn = DateTime.Now
                };

                ApplicationManager.Entities.AddToSlides(slide);
                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadSlidesList();
                this.LoadSlideShow();
                this.GenerateDisplayOrderList();
                this.ClearForm();
            }
            else
            {
                this.SetError("Vị trí ưu tiên đã được chọn");
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtID.Text))
            {
                var slide = _slides.FirstOrDefault(s => s.ID == int.Parse(txtID.Text));

                slide.Photo = txtPhotoUrl.Text;
                slide.Link = string.IsNullOrEmpty(txtLink.Text.Trim()) ? HostName + "/trang-chu.aspx" : txtLink.Text.Trim();
                slide.Description = txtDescription.Text.Trim();

                int? displayOrder = null;
                if (!string.IsNullOrEmpty(ddlDisplayOrder.SelectedValue))
                    displayOrder = int.Parse(ddlDisplayOrder.SelectedValue);
                slide.DisplayOrder = displayOrder;

                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadSlidesList();
                this.LoadSlideShow();
                this.GenerateDisplayOrderList();
                this.ClearForm();
            }
            else
            {
                this.SetError("Không tìm thấy slide");
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            this.GenerateDisplayOrderList();
            this.ClearForm();
        }

        private void LoadSlidesList()
        {
            grvSlides.DataSource = _slides.OrderBy(p => p.DisplayOrder == null)
                .ThenBy(p => p.DisplayOrder).ToList();
            grvSlides.DataBind();
        }

        private void GenerateDisplayOrderList()
        {
            this.GenerateDisplayOrderList(null);
        }

        private void GenerateDisplayOrderList(Data.ListOption usedPosition)
        {
            var positions = new List<Data.ListOption>
            { 
                new Data.ListOption { Value = null, Text = "[Chọn vị trí]" } 
            };

            for (int i = 1; i < 21; i++)
            {
                positions.Add(new Data.ListOption { Value = i, Text = string.Format("Vị trí {0}", i) });
            }

            var usedPositions = _slides.Where(s => s.DisplayOrder != null).Select(s => s.DisplayOrder);
            positions = positions.Where(p => !usedPositions.Contains(p.Value as int?)).ToList();

            if (usedPosition != null)
            {
                positions.Add(usedPosition);
                positions = positions.OrderBy(p => p.Value).ToList();
            }

            ddlDisplayOrder.DataSource = positions;
            ddlDisplayOrder.DataBind();
        }

        private void LoadSlideShow()
        {
            testSlideShow.DataSource = _slides.OrderBy(p => p.DisplayOrder == null)
                .ThenBy(p => p.DisplayOrder).ToList();
            testSlideShow.DataBind();
        }

        private void UpdateCacheData()
        {
            _slides = ApplicationManager.UpdateCacheData<Data.Slide>(ApplicationManager.Entities.Slides);
        }

        private void ClearForm()
        {
            txtID.Text = string.Empty;
            txtDescription.Text = string.Empty;
            txtPhotoUrl.Text = string.Empty;
            txtLink.Text = string.Empty;

            ddlDisplayOrder.SelectedIndex = 0;

            this.SetError(null);
        }

        private void SetError(string message)
        {
            message = string.IsNullOrEmpty(message) ? null : string.Format(ErrorBar, message);
            ltrError.Text = message;
        }
    }
}