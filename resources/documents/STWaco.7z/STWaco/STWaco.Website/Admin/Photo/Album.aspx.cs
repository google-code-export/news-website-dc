﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace STWaco.Website.Admin.Photo
{
    public partial class Album : BaseUI.AdminPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Cập Nhật Thư Viện Hình Ảnh";

            if (!IsPostBack)
            {
                this.LoadAlbumsList();
            }
        }

        protected void grvAlbums_SelectedIndexChanged(object sender, EventArgs e)
        {
            int albumID = int.Parse(grvAlbums.SelectedDataKey["ID"].ToString());
            var album = _albums.FirstOrDefault(b => b.ID == albumID);

            txtID.Text = albumID.ToString();
            txtTitle.Text = album.Title;
            txtAvatarUrl.Text = album.Avatar;
            txtDescription.Text = album.Description;
            txtPhotos.Text = album.Photos.Replace(';', '\n');

            this.SetError(null);
        }

        protected void grvAlbums_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var album = e.Row.DataItem as Data.Album;

                var lnkAvatar = e.Row.Cells[2].FindControl("lnkAvatar") as HyperLink;

                lnkAvatar.NavigateUrl = album.Avatar;
                lnkAvatar.Text = Path.GetFileName(album.Avatar);                
            }
        }

        protected void grvAlbums_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvAlbums.PageIndex = e.NewPageIndex;
        }

        protected void grvAlbums_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadAlbumsList();
        }

        protected void grvAlbums_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int albumID = int.Parse(grvAlbums.DataKeys[e.RowIndex]["ID"].ToString());
            var album = _albums.FirstOrDefault(b => b.ID == albumID);

            ApplicationManager.Entities.DeleteObject(album);
            ApplicationManager.Entities.SaveChanges();

            this.UpdateCacheData();
            this.LoadAlbumsList();

            if (!string.IsNullOrEmpty(txtID.Text) && txtID.Text == albumID.ToString())
                this.ClearForm();
            else
                this.SetError(null);
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            var album = new Data.Album
            {
                Title = txtTitle.Text.Trim(),
                Avatar = txtAvatarUrl.Text.Trim(),
                Description = txtDescription.Text.Trim(),
                Photos = txtPhotos.Text.Trim().Replace('\n', ';'),
                CreatedOn = DateTime.Now
            };

            ApplicationManager.Entities.AddToAlbums(album);
            ApplicationManager.Entities.SaveChanges();

            this.UpdateCacheData();
            this.LoadAlbumsList();
            this.ClearForm();           
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtID.Text))
            {
                var album = _albums.FirstOrDefault(b => b.ID == int.Parse(txtID.Text));

                album.Title = txtTitle.Text.Trim();
                album.Avatar = txtAvatarUrl.Text.Trim();
                album.Description = txtDescription.Text.Trim();
                album.Photos = txtPhotos.Text.Trim().Replace('\n', ';');

                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadAlbumsList();
                this.ClearForm();
            }
            else
            {
                this.SetError("Không tìm thấy album");
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearForm();
        }

        private void LoadAlbumsList()
        {
            grvAlbums.DataSource = _albums.OrderByDescending(p => p.CreatedOn);
            grvAlbums.DataBind();
        }

        private void UpdateCacheData()
        {
            _albums = ApplicationManager.UpdateCacheData<Data.Album>(ApplicationManager.Entities.Albums);
        }        

        private void ClearForm()
        {
            txtID.Text = string.Empty;
            txtTitle.Text = string.Empty;
            txtAvatarUrl.Text = string.Empty;
            txtDescription.Text = string.Empty;
            txtPhotos.Text = string.Empty;

            this.SetError(null);
        }

        private void SetError(string message)
        {
            message = string.IsNullOrEmpty(message) ? null : string.Format(ErrorBar, message);
            ltrError.Text = message;
        }
    }
}