﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace STWaco.Website.Admin.Photo
{
    public partial class Banner : BaseUI.AdminPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Cập Nhật Banner Quảng Cáo";
            
            if (!IsPostBack)
            {
                this.LoadBannersList();
                this.GenerateDisplayOrderList();                
            }
        }

        protected void grvBanners_SelectedIndexChanged(object sender, EventArgs e)
        {
            int bannerID = int.Parse(grvBanners.SelectedDataKey["ID"].ToString());
            var banner = _banners.FirstOrDefault(b => b.ID == bannerID);

            txtID.Text = bannerID.ToString();
            txtPhotoUrl.Text = banner.Photo;
            txtHeight.Text = banner.Height.ToString();
            txtLink.Text = banner.Link;            

            ddlPositions.Text = banner.Position;

            if (banner.DisplayOrder.HasValue)
            {
                this.GenerateDisplayOrderList(new Data.ListOption
                {
                    Value = banner.DisplayOrder.Value,
                    Text = string.Format("Vị trí {0}", banner.DisplayOrder.Value)
                });
            }

            ddlDisplayOrder.Text = banner.DisplayOrder.ToString();

            this.SetError(null);
        }

        protected void grvBanners_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var banner = e.Row.DataItem as Data.Banner;

                var lnkPhoto = e.Row.Cells[2].FindControl("lnkPhoto") as HyperLink;
                var ltrPosition = e.Row.Cells[3].FindControl("ltrPosition") as Literal;

                lnkPhoto.NavigateUrl = banner.Photo;
                lnkPhoto.Text = Path.GetFileName(banner.Photo);

                var posDic = new Dictionary<string, string>();
                posDic.Add("Left", "Trái");
                posDic.Add("Right", "Phải");
                posDic.Add("Top", "Trên");
                posDic.Add("Bottom", "Dưới");

                ltrPosition.Text = posDic[banner.Position];
            }
        }

        protected void grvBanners_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvBanners.PageIndex = e.NewPageIndex;
        }

        protected void grvBanners_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadBannersList();
        }

        protected void grvBanners_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int bannerID = int.Parse(grvBanners.DataKeys[e.RowIndex]["ID"].ToString());
            var banner = _banners.FirstOrDefault(b => b.ID == bannerID);

            ApplicationManager.Entities.DeleteObject(banner);
            ApplicationManager.Entities.SaveChanges();

            this.UpdateCacheData();
            this.LoadBannersList();
            this.GenerateDisplayOrderList();

            if (!string.IsNullOrEmpty(txtID.Text) && txtID.Text == bannerID.ToString())
                this.ClearForm();
            else
                this.SetError(null);
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            int? displayOrder = null;
            if (!string.IsNullOrEmpty(ddlDisplayOrder.SelectedValue))
            {
                displayOrder = int.Parse(ddlDisplayOrder.SelectedValue);
            }

            var usedPositions = _banners.Where(s => s.DisplayOrder != null).Select(s => s.DisplayOrder);

            if (!usedPositions.Contains(displayOrder))
            {
                var banner = new Data.Banner
                {                    
                    Link = txtLink.Text.Trim(),
                    Photo = txtPhotoUrl.Text.Trim(),
                    Position = ddlPositions.SelectedValue,
                    DisplayOrder = displayOrder,
                    CreatedOn = DateTime.Now
                };

                if (!string.IsNullOrEmpty(txtHeight.Text.Trim()))
                    banner.Height = int.Parse(txtHeight.Text);

                ApplicationManager.Entities.AddToBanners(banner);
                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadBannersList();
                this.GenerateDisplayOrderList();
                this.ClearForm();
            }
            else
            {
                this.SetError("Vị trí ưu tiên đã được chọn");
            }                       
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtID.Text))
            {
                var banner = _banners.FirstOrDefault(b => b.ID == int.Parse(txtID.Text));
               
                banner.Link = txtLink.Text.Trim();
                banner.Photo = txtPhotoUrl.Text.Trim();
                banner.Position = ddlPositions.SelectedValue;

                if (!string.IsNullOrEmpty(txtHeight.Text.Trim()))
                    banner.Height = int.Parse(txtHeight.Text);

                int? displayOrder = null;
                if (!string.IsNullOrEmpty(ddlDisplayOrder.SelectedValue))
                    displayOrder = int.Parse(ddlDisplayOrder.SelectedValue);
                banner.DisplayOrder = displayOrder;

                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadBannersList();
                this.GenerateDisplayOrderList();
                this.ClearForm();
            }
            else
            {
                this.SetError("Không tìm thấy banner");
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearForm();
        }

        private void LoadBannersList()
        {
            grvBanners.DataSource = _banners.OrderBy(p => p.DisplayOrder == null)
                .ThenBy(p => p.DisplayOrder).ToList();
            grvBanners.DataBind();
        }        

        private void UpdateCacheData()
        {
            _banners = ApplicationManager.UpdateCacheData<Data.Banner>(ApplicationManager.Entities.Banners);
        }

        private void GenerateDisplayOrderList()
        {
            this.GenerateDisplayOrderList(null);
        }

        private void GenerateDisplayOrderList(Data.ListOption usedPosition)
        {
            var positions = new List<Data.ListOption>
            { 
                new Data.ListOption { Value = null, Text = "[Chọn vị trí]" } 
            };

            for (int i = 1; i < 21; i++)
            {
                positions.Add(new Data.ListOption { Value = i, Text = string.Format("Vị trí {0}", i) });
            }

            var usedPositions = _banners.Where(s => s.DisplayOrder != null).Select(s => s.DisplayOrder);
            positions = positions.Where(p => !usedPositions.Contains(p.Value as int?)).ToList();

            if (usedPosition != null)
            {
                positions.Add(usedPosition);
                positions = positions.OrderBy(p => p.Value).ToList();
            }

            ddlDisplayOrder.DataSource = positions;
            ddlDisplayOrder.DataBind();
        }

        private void ClearForm()
        {
            txtID.Text = string.Empty;
            txtPhotoUrl.Text = string.Empty;
            txtHeight.Text = string.Empty;
            txtLink.Text = string.Empty;

            ddlPositions.SelectedIndex = 0;
            ddlDisplayOrder.SelectedIndex = 0;

            this.SetError(null);
        }

        private void SetError(string message)
        {
            message = string.IsNullOrEmpty(message) ? null : string.Format(ErrorBar, message);
            ltrError.Text = message;
        }
    }
}