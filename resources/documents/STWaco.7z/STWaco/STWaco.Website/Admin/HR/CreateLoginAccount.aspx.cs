﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace STWaco.Website.Admin.HR
{
    public partial class CreateLoginAccount : BaseUI.AdminPage
    {
        private Data.ListOption resultSet = new Data.ListOption();

        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Tạo Tài Khoản Web";
            
            if (!IsPostBack)
            {
                this.LoadAllRoles();
            }
        }

        protected void btnCreate_Click(object sender, EventArgs e)
        {
            MembershipCreateStatus createStatus;
            
            var newUser = Membership.CreateUser(txtUserName.Text, txtConfirmPassword.Text, txtEmail.Text, ddlQuestions.SelectedItem.Text, txtAnswer.Text, true, out createStatus);
            
            switch (createStatus)
            {
                case MembershipCreateStatus.Success:
                    resultSet.Text = "Tạo tài khoản thành công!";
                    resultSet.Value = true;
                    break;
                case MembershipCreateStatus.DuplicateUserName:
                    resultSet.Text = "Tài khoản này đã tồn tại.";
                    resultSet.Value = false;
                    break;
                case MembershipCreateStatus.DuplicateEmail:
                    resultSet.Text = "Email này đã tồn tại.";
                    resultSet.Value = false;
                    break;
                case MembershipCreateStatus.InvalidEmail:
                    resultSet.Text = "Email không hợp lệ.";
                    resultSet.Value = false;
                    break;
                case MembershipCreateStatus.InvalidAnswer:
                    resultSet.Text = "Câu trả lời không hợp lệ.";
                    resultSet.Value = false;
                    break;
                case MembershipCreateStatus.InvalidPassword:
                    resultSet.Text = "Mật khẩu không hợp lệ.";
                    resultSet.Value = false;
                    break;
                default:
                    resultSet.Text = "Không tạo được tài khoản. Vui lòng thử lại.";
                    resultSet.Value = false;
                    break;
            }

            if ((bool)resultSet.Value)
            {
                Roles.AddUserToRole(newUser.UserName, ddlRoles.SelectedValue);

                txtUserName.Text = string.Empty;
                txtEmail.Text = string.Empty;
                ddlQuestions.SelectedIndex = 0;
                txtAnswer.Text = string.Empty;
            }

            string resultFrame = (bool)resultSet.Value ? InfoBar : ErrorBar;

            ltrResult.Text = string.Format(resultFrame, resultSet.Text);
        }

        private void LoadAllRoles()
        {
            ddlRoles.DataSource = Roles.GetAllRoles();
            ddlRoles.DataBind();
        }
    }
}