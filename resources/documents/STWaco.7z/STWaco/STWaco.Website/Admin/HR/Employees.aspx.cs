﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace STWaco.Website.Admin.HR
{
    public partial class Employees : BaseUI.AdminPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Quản Lý Nhân Viên";
            
            if (!IsPostBack)
            {                
                this.LoadDepartMentLists();
                this.LoadEmpoyeesList();
            }
        }

        protected void grvEmployees_SelectedIndexChanged(object sender, EventArgs e)
        {
            var employeeID = grvEmployees.SelectedDataKey["ID"].ToString();
            var empl = _empl.FirstOrDefault(t => t.ID == employeeID);
            txtID.Text = empl.ID;
            txtName.Text = empl.Name;
            ddlSex.Text = empl.Sex;
            txtDOB.Text = string.Format("{0:dd/MM/yyyy}", empl.Birthday);
            txtHiredDate.Text = string.Format("{0:dd/MM/yyyy}", empl.HireDate);
            txtChucVu.Text = empl.Possition;
            txtSodienthoai.Text = empl.PhoneNo;
            txtEmail.Text = empl.Email;
            txtAddress.Text = empl.Address;
            ddlDepartment.Text = empl.Grouping_Rooms.RoomID.ToString();
            this.SetError(null);
        }

        protected void grvEmployees_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvEmployees.PageIndex = e.NewPageIndex;
        }

        protected void grvEmployees_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadEmpoyeesList();
        }

        protected void grvEmployees_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var employeeID = grvEmployees.DataKeys[e.RowIndex]["ID"].ToString();
            var empl = _empl.FirstOrDefault(t => t.ID == employeeID);

            ApplicationManager.Entities.DeleteObject(empl);
            ApplicationManager.Entities.SaveChanges();

            this.UpdateCacheData();
            this.LoadEmpoyeesList();
            this.SetError(null);
            if (!string.IsNullOrEmpty(txtID.Text) && employeeID == txtID.Text)
                this.ClearForm();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            
            try
            {
                var de = _dept.FirstOrDefault(m => m.RoomID == int.Parse(ddlDepartment.SelectedValue));
                
                var empl = new Data.Employee
                {
                    ID = txtID.Text.Trim(),
                    Name = txtName.Text,
                    Sex = ddlSex.Text,
                    Birthday = DateTime.Parse(txtDOB.Text),
                    HireDate = DateTime.Parse(txtHiredDate.Text),
                    Possition = txtChucVu.Text,
                    PhoneNo = txtSodienthoai.Text,
                    Email = txtEmail.Text,
                    Address = txtAddress.Text,
                    Grouping_Rooms = de,

                };

                ApplicationManager.Entities.AddToEmployees(empl);
                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadEmpoyeesList();
                this.ClearForm();
            }
            catch (Exception ex)
            {
                this.SetError(ex.Message);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            var de = _dept.FirstOrDefault(m => m.RoomID == int.Parse(ddlDepartment.SelectedValue));
            
            try
            {
                var empl = _empl.FirstOrDefault(t => t.ID == txtID.Text);

                if (empl != null)
                {
                    empl.Name = txtName.Text;
                    empl.Sex = ddlSex.Text;
                    empl.Birthday = DateTime.Parse(txtDOB.Text);
                    empl.HireDate = DateTime.Parse(txtHiredDate.Text);
                    empl.Possition = txtChucVu.Text;
                    empl.PhoneNo = txtSodienthoai.Text;
                    empl.Email = txtEmail.Text;
                    empl.Address = txtAddress.Text;
                    empl.Grouping_Rooms = de;
                    ApplicationManager.Entities.SaveChanges();

                    this.UpdateCacheData();
                    this.LoadEmpoyeesList();
                    this.ClearForm();
                }
                else
                {
                    this.SetError("Không tìm thấy thành viên này.");
                }
            }
            catch (Exception ex)
            {
                this.SetError(ex.Message);
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearForm();
        }

        private void LoadEmpoyeesList()
        {
            grvEmployees.DataSource = _empl.OrderByDescending(t => t.ID).ToList();
            grvEmployees.DataBind();
        }

        private void UpdateCacheData()
        {
            _empl = ApplicationManager.UpdateCacheData<Data.Employee>(ApplicationManager.Entities.Employees, "AdminList");
        }

        private void ClearForm()
        {
            txtID.Text = string.Empty;
            txtName.Text = string.Empty;
            ddlSex.Text = string.Empty;
            txtDOB.Text = string.Empty;
            txtHiredDate.Text = string.Empty;
            txtChucVu.Text = string.Empty;
            txtSodienthoai.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtAddress.Text = string.Empty;
            ddlDepartment.SelectedIndex = -1;
            txtID.Focus();
        }

        private void SetError(string message)
        {
            message = string.IsNullOrEmpty(message) ? null : string.Format(ErrorBar, message);
            ltrError.Text = message;
        }

        protected void grvEmployees_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var empl = e.Row.DataItem as Data.Employee;
                var ltrDept = e.Row.Cells[4].FindControl("ltrDepartment") as Literal;
                ltrDept.Text = empl.Grouping_Rooms.Name;
            }
        }

        private void LoadDepartMentLists()
        {
            var de = _dept.ToList();
            de.Insert(0, new Data.Grouping_Rooms { RoomID = -1, Name = "[Chọn phòng ban]" });

            ddlDepartment.DataSource = de;
            ddlDepartment.DataBind();
        }
    }
}