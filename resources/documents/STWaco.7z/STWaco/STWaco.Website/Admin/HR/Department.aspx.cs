﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Admin.HR
{
    public partial class Department : BaseUI.AdminPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Quản Lý Phòng Ban";
            
            if (!IsPostBack)
            {                
                this.LoadDepartmentList();
            }
        }

        protected void grvDepartments_SelectedIndexChanged(object sender, EventArgs e)
        {
            var deptRoomID = int.Parse(grvDepartments.SelectedDataKey["RoomID"].ToString());
            var dept = _dept.FirstOrDefault(t => t.RoomID == deptRoomID);

            txtID.Text = dept.RoomID.ToString();
            txtName.Text = dept.Name;

            this.SetError(null);
        }

        protected void grvDepartments_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvDepartments.PageIndex = e.NewPageIndex;
        }

        protected void grvDepartments_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadDepartmentList();
        }

        protected void grvDepartments_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var deptRoomID = int.Parse(grvDepartments.DataKeys[e.RowIndex]["RoomID"].ToString());
            var dept = _dept.FirstOrDefault(t => t.RoomID == deptRoomID);

            ApplicationManager.Entities.DeleteObject(dept);
            ApplicationManager.Entities.SaveChanges();

            this.UpdateCacheData();
            this.LoadDepartmentList();
            this.SetError(null);
            if (!string.IsNullOrEmpty(txtID.Text) && deptRoomID == int.Parse(txtID.Text))
                this.ClearForm();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                var dept = new Data.Grouping_Rooms
                {
                    Name = txtName.Text.Trim(),
                };

                ApplicationManager.Entities.AddToGrouping_Rooms(dept);
                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadDepartmentList();
                this.ClearForm();
            }
            catch (Exception ex)
            {
                this.SetError(ex.Message);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtID.Text))
                {
                    var dept = _dept.FirstOrDefault(t => t.RoomID == int.Parse(txtID.Text));
                    dept.Name = txtName.Text.Trim();
                    ApplicationManager.Entities.SaveChanges();

                    this.UpdateCacheData();
                    this.LoadDepartmentList();
                    this.ClearForm();
                }
                else
                {
                    this.SetError("Không tìm thấy phòng ban");
                }
            }
            catch (Exception ex)
            {
                this.SetError(ex.Message);
            }
        }

        private void LoadDepartmentList()
        {
            grvDepartments.DataSource = _dept.OrderByDescending(t => t.RoomID).ToList();
            grvDepartments.DataBind();
        }

        private void UpdateCacheData()
        {
            //ApplicationManager.UpdateCacheData<Data.Department>(ApplicationManager.Entities.Departments.Where(t => !t.Deleted));
            _dept = ApplicationManager.UpdateCacheData<Data.Grouping_Rooms>(ApplicationManager.Entities.Grouping_Rooms, "AdminList");
        }

        private void ClearForm()
        {
            txtID.Text = string.Empty;
            txtName.Text = string.Empty;
            ltrError.Text = string.Empty;
            txtName.Focus();
        }

        private void SetError(string message)
        {
            message = string.IsNullOrEmpty(message) ? null : string.Format(ErrorBar, message);
            ltrError.Text = message;
        }
    }
}