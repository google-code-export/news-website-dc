﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Admin.Other
{
    public partial class Contact : BaseUI.AdminPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Thông Tin Liên Hệ";

            if (!IsPostBack)
            {
                this.LoadContactsList();
            }
        }

        protected void grvContacts_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.SelectContact();
        }

        protected void grvContacts_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvContacts.PageIndex = e.NewPageIndex;
        }

        protected void grvContacts_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadContactsList();
        }

        protected void grvContacts_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var contactID = int.Parse(grvContacts.DataKeys[e.RowIndex]["ID"].ToString());
            var contact = _contacts.FirstOrDefault(c => c.ID == contactID);

            ApplicationManager.Entities.DeleteObject(contact);
            ApplicationManager.Entities.SaveChanges();

            this.UpdateCacheData();
            this.LoadContactsList();
        }

        private void LoadContactsList()
        {
            grvContacts.DataSource = _contacts.OrderByDescending(c => c.CreatedOn).ThenBy(c => c.Email).ToList();
            grvContacts.DataBind();

            if (grvContacts.Rows.Count > 0)
            {
                grvContacts.SelectedIndex = 0;
                this.SelectContact();
            }
        }

        private void SelectContact()
        {
            var contactID = int.Parse(grvContacts.SelectedDataKey["ID"].ToString());
            var contact = _contacts.FirstOrDefault(c => c.ID == contactID);

            lblID.Text = contact.ID.ToString();
            lblName.Text = contact.Name;
            ltrEmail.Text = string.Format("<a href=\"mailto:{0}\">{0}</a>", contact.Email);
            lblPhone.Text = string.IsNullOrEmpty(contact.Phone) ? "Chưa có thông tin" : contact.Phone;
            lblCompany.Text = string.IsNullOrEmpty(contact.Company) ? "Chưa có thông tin" : contact.Company;
            ltrWebsite.Text = string.IsNullOrEmpty(contact.Website) ? "<span>Chưa có thông tin</span>"
                : string.Format("<a href=\"{0}\" targer=\"_blank\" rel=\"nofollow\">{0}</a>", contact.Website);
            ltrMessage.Text = string.Format("<p class=\"message\">{0}</p>", contact.Message);
        }

        private void UpdateCacheData()
        {
            _contacts = ApplicationManager.UpdateCacheData<Data.Contact>(ApplicationManager.Entities.Contacts);
        }
    }
}