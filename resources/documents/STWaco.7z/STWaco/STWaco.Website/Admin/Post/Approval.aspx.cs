﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Admin.Post
{
    public partial class Approval : BaseUI.AdminPage
    {
        private static IList<Data.Post> _currentPosts;

        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Duyệt Bài Viết";

            if (!IsPostBack)
            {
                _currentPosts = _posts.Where(p => !p.Approved).OrderByDescending(p => p.CreatedOn).ToList();

                this.LoadPostsList();
                this.LoadCategoriesLists();
            }
        }

        protected void ddlCategoriesFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            int cateID = int.Parse(ddlCategoriesFilter.SelectedValue);

            var flow = _posts.AsQueryable();
            if (cateID != -1) flow = flow.Where(f => f.Category.ID == cateID);

            _currentPosts = flow.Where(p => !p.Approved).OrderByDescending(f => f.CreatedOn).ToList();
            this.LoadPostsList();
        }

        protected void grvPosts_SelectedIndexChanged(object sender, EventArgs e)
        {
            int postID = int.Parse(grvPosts.SelectedDataKey["ID"].ToString());
            var post = _posts.FirstOrDefault(p => p.ID == postID);

            txtID.Text = postID.ToString();
            txtTitle.Text = post.Title;
            txtCreatedOn.Text = string.Format("{0:dd/MM/yyyy}", post.CreatedOn);
            txtDescription.Text = post.Description;

            txtPhotoUrl.Text = post.Photo;

            ddlCategories.Text = post.Category.ID.ToString();
            editorContent.Text = post.Content;

            this.SetError(null);
        }

        protected void grvPosts_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var post = e.Row.DataItem as Data.Post;
                var ltrCategory = e.Row.Cells[3].FindControl("ltrCategory") as Literal;
                ltrCategory.Text = post.Category.Name;
            }
        }

        protected void grvPosts_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvPosts.PageIndex = e.NewPageIndex;
        }

        protected void grvPosts_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadPostsList();
        }

        protected void grvPosts_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            int postID = int.Parse(grvPosts.DataKeys[e.RowIndex]["ID"].ToString());
            var post = _posts.FirstOrDefault(p => p.ID == postID);

            ApplicationManager.Entities.DeleteObject(post);
            ApplicationManager.Entities.SaveChanges();

            this.UpdateCacheData();

            _currentPosts = _posts.Where(p => !p.Approved).OrderByDescending(p => p.CreatedOn).ToList();
            this.LoadPostsList();

            if (!string.IsNullOrEmpty(txtID.Text) && txtID.Text == postID.ToString())
                this.ClearForm();
            else
                this.SetError(null);
        }

        protected void grvPosts_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                if (e.CommandName.Equals("Approve"))
                {
                    int postID = int.Parse(e.CommandArgument.ToString());
                    var post = _posts.FirstOrDefault(p => p.ID == postID);

                    post.Approved = true;

                    ApplicationManager.Entities.SaveChanges();

                    this.UpdateCacheData();

                    _currentPosts = _posts.Where(p => !p.Approved).OrderByDescending(p => p.CreatedOn).ToList();
                    this.LoadPostsList();
                }
            }
            catch (Exception ex)
            {
                this.SetError(ex.Message);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtID.Text))
            {
                var post = _posts.FirstOrDefault(p => p.ID == int.Parse(txtID.Text));
                var cate = _cates.FirstOrDefault(t => t.ID == int.Parse(ddlCategories.SelectedValue));

                post.Title = txtTitle.Text.Trim();
                post.Description = txtDescription.Text.Trim();
                post.Photo = txtPhotoUrl.Text;
                post.Category = cate;
                post.Content = editorContent.Text;
                post.CreatedBy = HttpContext.Current.User.Identity.Name;
                post.CreatedOn = DateTime.Parse(txtCreatedOn.Text);
                post.UpdatedOn = DateTime.Now;
                post.Approved = false;

                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadPostsList();
                this.ClearForm();
            }
            else
            {
                this.SetError("Không tìm thấy bài viết");
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearForm();
        }

        private void LoadPostsList()
        {
            grvPosts.DataSource = _currentPosts;
            grvPosts.DataBind();
        }

        private void LoadCategoriesLists()
        {
            var cates = _cates.ToList();
            cates.Insert(0, new Data.Category { ID = -1, Name = "[Chọn chủ đề]" });

            ddlCategoriesFilter.DataSource = cates;
            ddlCategoriesFilter.DataBind();

            ddlCategories.DataSource = cates;
            ddlCategories.DataBind();
        }

        private void UpdateCacheData()
        {
            _posts = ApplicationManager.UpdateCacheData<Data.Post>(ApplicationManager.Entities.Posts, "AdminList");
            ApplicationManager.UpdateCacheData<Data.Post>(ApplicationManager.Entities.Posts.Where(p => p.Approved), "SecuredList");
            ApplicationManager.UpdateCacheData<Data.Post>(ApplicationManager.Entities.Posts.Where(p => p.Approved && !p.Category.Secured));
        }

        private void ClearForm()
        {
            txtID.Text = string.Empty;
            txtTitle.Text = string.Empty;
            txtCreatedOn.Text = string.Empty;
            txtDescription.Text = string.Empty;

            txtPhotoUrl.Text = string.Empty;

            ddlCategories.SelectedIndex = 0;

            editorContent.Text = string.Empty;

            this.SetError(null);
            txtTitle.Focus();
        }

        private void SetError(string message)
        {
            message = string.IsNullOrEmpty(message) ? null : string.Format(ErrorBar, message);
            ltrError.Text = message;
        }
    }
}