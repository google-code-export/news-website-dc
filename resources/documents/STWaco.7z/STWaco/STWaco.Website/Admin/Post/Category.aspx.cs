﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Admin.Post
{
    public partial class Category : BaseUI.AdminPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Cập Nhật Chủ Đề";
            
            if (!IsPostBack)
            {
                this.LoadCategoriesList();
            }
        }

        protected void grvCategories_SelectedIndexChanged(object sender, EventArgs e)
        {
            var cateID = int.Parse(grvCategories.SelectedDataKey["ID"].ToString());
            var cate = _cates.FirstOrDefault(t => t.ID == cateID);

            txtID.Text = cate.ID.ToString();
            txtName.Text = cate.Name;
            txtDescription.Text = cate.Description;
            chkSecured.Checked = cate.Secured;
            chkDeleted.Checked = cate.Deleted;

            this.SetError(null);
        }

        protected void grvCategories_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvCategories.PageIndex = e.NewPageIndex;
        }

        protected void grvCategories_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadCategoriesList();
        }

        protected void grvCategories_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var cateID = int.Parse(grvCategories.DataKeys[e.RowIndex]["ID"].ToString());
            var cate = _cates.FirstOrDefault(t => t.ID == cateID);

            if (cate.Posts.Count == 0)
            {
                ApplicationManager.Entities.DeleteObject(cate);
                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadCategoriesList();
                this.SetError(null);
                if (!string.IsNullOrEmpty(txtID.Text) && cateID == int.Parse(txtID.Text))
                    this.ClearForm();
            }
            else
            {
                this.SetError("Chủ đề này đang sử dụng");
                e.Cancel = true;
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                var cate = new Data.Category
                {
                    Name = txtName.Text.Trim(),
                    Description = txtDescription.Text.Trim(),
                    Secured = chkSecured.Checked,
                    Deleted = chkDeleted.Checked,
                    CreatedOn = DateTime.Now
                };

                ApplicationManager.Entities.AddToCategories(cate);
                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadCategoriesList();
                this.ClearForm();
            }
            catch (Exception ex)
            {
                this.SetError(ex.Message);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtID.Text))
                {
                    var cate = _cates.FirstOrDefault(t => t.ID == int.Parse(txtID.Text));

                    cate.Name = txtName.Text.Trim();
                    cate.Description = txtDescription.Text.Trim();
                    cate.Secured = chkSecured.Checked;
                    cate.Deleted = chkDeleted.Checked;
                    cate.UpdatedOn = DateTime.Now;
                    ApplicationManager.Entities.SaveChanges();

                    this.UpdateCacheData();
                    this.LoadCategoriesList();
                    this.ClearForm();
                }
                else
                {
                    this.SetError("Không tìm thấy chủ đề");
                }
            }
            catch (Exception ex)
            {
                this.SetError(ex.Message);
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearForm();
        }

        private void LoadCategoriesList()
        {
            grvCategories.DataSource = _cates.OrderByDescending(t => t.CreatedOn).ToList();
            grvCategories.DataBind();
        }

        private void UpdateCacheData()
        {
            ApplicationManager.UpdateCacheData<Data.Category>(ApplicationManager.Entities.Categories.Where(c => !c.Deleted));
            _cates = ApplicationManager.UpdateCacheData<Data.Category>(ApplicationManager.Entities.Categories, "AdminList");
        }

        private void ClearForm()
        {
            txtID.Text = string.Empty;
            txtName.Text = string.Empty;
            txtDescription.Text = string.Empty;
            chkSecured.Checked = false;
            chkDeleted.Checked = false;
            ltrError.Text = string.Empty;
            txtName.Focus();
        }

        private void SetError(string message)
        {
            message = string.IsNullOrEmpty(message) ? null : string.Format(ErrorBar, message);
            ltrError.Text = message;
        }
    }
}