﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website
{
    public partial class WaterInfoDetails : BaseUI.BasePage
    {
        private string _custID = string.Empty;
        private static Data.Customer _cus;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Kết Quả Chi Tiết";
            
            if (!IsPostBack)
            {
                _custID = Request.QueryString["id"];
                this.LoadSearchResults();
            }
        }

        private void LoadSearchResults()
        {
            IQueryable<Data.WaterComsumption> query = _waterconsump; int i = 0;

            if (!string.IsNullOrEmpty(_custID))
            {
                _cus = _cust.FirstOrDefault(p => p.ID == _custID);
                { query = query.Where(p => p.Customer == _cus); i++; }
                
            }
            var result = i > 0 ? query.ToList() : new List<Data.WaterComsumption>();     

            ucWaterInfoDetails.DataSourceWaterConsump = result;
            ucWaterInfoDetails.DataBind();
        }
    }
}