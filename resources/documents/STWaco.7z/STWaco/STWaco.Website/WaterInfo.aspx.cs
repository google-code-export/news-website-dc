﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

namespace STWaco.Website
{
    public partial class WaterInfo : BaseUI.BasePage
    {
        private string _sodanhbo = string.Empty;
        private string _khachhang = string.Empty;
        private string _sonha = string.Empty;
        private string _tenduong = string.Empty;
        private string _khuvuc = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Tra Cứu Nước";
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            _sodanhbo = Server.HtmlEncode(txtSoDanhBo.Text.Trim().ToLower());
            _khachhang = Server.HtmlEncode(txtKhachHang.Text.Trim().ToLower());
            _sonha = Server.HtmlEncode(txtSoNha.Text.Trim().ToLower());
            _tenduong = Server.HtmlEncode(txtTenDuong.Text.Trim().ToLower());
            _khuvuc = ddlKhuVuc.SelectedValue.Trim().ToLower();
            LoadSearchResults();
        }

        private void LoadSearchResults()
        {
            IQueryable<Data.Customer> query = _cust; int i = 0;

            if (!string.IsNullOrEmpty(_sodanhbo))
            { query = query.Where(p => p.ID.ToLower().Contains(_sodanhbo)); i++; }
            if (!string.IsNullOrEmpty(_khachhang))
            { query = query.Where(p => p.Name.ToLower().Contains(_khachhang)); i++; }
            if (!string.IsNullOrEmpty(_sonha))
            { query = query.Where(p => p.Address.ToLower().Contains(_sonha)); i++; }
            if (!string.IsNullOrEmpty(_tenduong))
            { query = query.Where(p => p.Address.ToLower().Contains(_tenduong)); i++; }
            if (!string.IsNullOrEmpty(_khuvuc))
            { query = query.Where(p => p.Address.ToLower().Contains(_khuvuc)); i++; }

            var result = i > 0 ? query.ToList() : new List<Data.Customer>();
            
            cbResult.DataSource = result;
            cbResult.DataBind();
        }
    }
}