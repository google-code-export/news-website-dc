﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website
{
    public partial class Extra : BaseUI.BaseMaster
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.LoadSideMenu();
                this.LoadAdBox();
            }
        }

        private void LoadSideMenu()
        {
            _SideMenu.Posts = ApplicationManager.SetCacheData<Data.Post>(ApplicationManager.Entities.Posts, null).ToList();
            _SideMenu.DataBind();
        }

        private void LoadAdBox()
        {
            leftAdBox.DataSource = _banners.Where(b => b.Position.Equals("Left")).ToList();
            leftAdBox.DataBind();

            rightAdBox.DataSource = _banners.Where(b => b.Position.Equals("Right")).ToList();
            rightAdBox.DataBind();
        }
    }
}