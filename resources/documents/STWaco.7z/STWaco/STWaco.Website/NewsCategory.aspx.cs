﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website
{
    public partial class NewsCategory : BaseUI.BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Danh Mục Tin Tức";
            
            if (!IsPostBack)
            {
                string timescope = Request.QueryString["scope"];

                if (string.IsNullOrEmpty(timescope))
                {
                    nsList.Posts = _posts.Where(p => p.Category.Name.Trim().ToLower().Equals("tin tức")).ToList();    
                }
                else
                {
                    int month = int.Parse(timescope.Split(' ')[0]);
                    int year = int.Parse(timescope.Split(' ')[1]);

                    nsList.Posts = _posts.Where(p => p.Category.Name.Trim().ToLower().Equals("tin tức")
                        && p.CreatedOn.Month == month && p.CreatedOn.Year == year).ToList();
                }
                                
                nsList.CategoryDir = "tin-tuc";
                nsList.DataBind();
            }
        }
    }
}