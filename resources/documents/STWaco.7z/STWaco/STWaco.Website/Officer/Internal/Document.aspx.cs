﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using Telerik.Web.UI;
using CuteWebUI;
using System.Globalization;
using STWaco.Data;

namespace STWaco.Website.Officer.Internal
{
    public partial class Document : BaseUI.OfficerPage
    {
        private static string _currentPath;

        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Quản Lý Công Văn";

            if (!IsPostBack)
            {
                this.LoadDocummentList();
                this.LoadCoQuanLists();
                this.LoadTheLoaiLists();
                this.LoadDonViSoanLists();
                this.LoadLanhDaoLists();
            }
        }

        private void LoadCoQuanLists()
        {
            var coquan = _dscq.ToList();
            //donvi.Insert(0, new Data.DSCQ { MACQ = "0", TENCQ = "[Chọn đơn vị gởi(nhận)]" });

            ddlDonViGoiNhan.DataSource = coquan;
            ddlDonViGoiNhan.DataTextField = "TENCQ";
            ddlDonViGoiNhan.DataValueField = "MACQ";
            ddlDonViGoiNhan.DataBind();
        }

        private void LoadTheLoaiLists()
        {
            var theloai = _tlvb.ToList();

            ddlTheLoai.DataSource = theloai;
            ddlTheLoai.DataTextField = "TENTL";
            ddlTheLoai.DataValueField = "MATL";
            ddlTheLoai.DataBind();
        }

        private void LoadDonViSoanLists()
        {
            var donvisoan = _dsdv.ToList();
            donvisoan.Insert(0, new Data.DSDV { MADV = "", TENDV = "[Chọn đơn vị soạn]" });
            ddlDonViSoan.DataSource = donvisoan;
            ddlDonViSoan.DataTextField = "TENDV";
            ddlDonViSoan.DataValueField = "MADV";
            ddlDonViSoan.DataBind();
        }

        private void LoadLanhDaoLists()
        {
            var lanhdao = _bgd.ToList();
            //donvi.Insert(0, new Data.DSCQ { MACQ = "0", TENCQ = "[Chọn đơn vị gởi(nhận)]" });

            ddlLanhDao.DataSource = lanhdao;
            ddlLanhDao.DataTextField = "TENLD";
            ddlLanhDao.DataValueField = "MALD";
            ddlLanhDao.DataBind();
        }

        protected void grvDocumments_SelectedIndexChanged(object sender, EventArgs e)
        {
            var docId = grvDocumments.SelectedDataKey["SOCVD"].ToString();
            var docs = _docs.FirstOrDefault(t => t.SOCVD == docId);

            txtMaCongVan.Text = docs.SOCVD;
            txtNgayCongVanDen.Text = String.Format("{0:dd/MM/yyyy}", docs.NGAYCVD); 
            txtSoCongVan.Text = docs.SOCV;
            txtNgayCongVanGoc.Text = String.Format("{0:dd/MM/yyyy}", docs.NGAYCV); 
            ddlDonViGoiNhan.SelectedValue = docs.DSCQ.MACQ;
            ddlTheLoai.SelectedValue = docs.TLVB.MATL;
            if (docs.DSDV == null)
            {
                ddlDonViSoan.SelectedValue = "";
            }
            else
            {
                ddlDonViSoan.SelectedValue = docs.DSDV.MADV;
            }
            txtNoiDung.Text = docs.NOIDUNG;
            ddlLanhDao.SelectedValue = docs.BGD.MALD;
            txtSaoGoi.Text = docs.SAOGUI;
            txtYKien.Text = docs.YKIENGQ;
            txtGhiChu.Text = docs.GHICHU;
            txtUrl.Text = docs.FileUrl;
            chkHidden.Checked = docs.Hidden;
            this.SetError(null);
        }

        protected void grvDocumments_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvDocumments.PageIndex = e.NewPageIndex;
        }

        protected void grvDocumments_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadDocummentList();
        }

        protected void grvDocumments_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var docId = grvDocumments.DataKeys[e.RowIndex]["SOCVD"].ToString();
            var docs = _docs.FirstOrDefault(t => t.SOCVD == docId);

            ApplicationManager.Entities.DeleteObject(docs);
            ApplicationManager.Entities.SaveChanges();

            this.UpdateCacheData();
            this.LoadDocummentList();
            this.SetError(null);
            //if (!string.IsNullOrEmpty(txtID.Text) && waterconsumpId == txtID.Text)
            this.ClearForm();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            var coquan = _dscq.FirstOrDefault(t => t.MACQ == ddlDonViGoiNhan.SelectedValue);
            var theloai = _tlvb.FirstOrDefault(t => t.MATL == ddlTheLoai.SelectedValue);
            var donvi = _dsdv.FirstOrDefault(t => t.MADV == ddlDonViSoan.SelectedValue);
            var lanhdao = _bgd.FirstOrDefault(t => t.MALD == ddlLanhDao.SelectedValue);

            //DateTimeFormatInfo dtfi = new DateTimeFormatInfo();
            //dtfi.ShortDatePattern = "MM/dd/yyyy";
            //DateTime ngayden = Convert.ToDateTime(txtNgayCongVanDen.Text.Trim(),dtfi);
            //DateTime ngaygoc = Convert.ToDateTime(txtNgayCongVanGoc.Text.Trim(), dtfi);
            try
            {
                var document = new Data.CONGVAN
                {
                    SOCVD = txtMaCongVan.Text,
                    NGAYCVD = (txtNgayCongVanDen.Text == "") ?  DateTime.Now.Date : DateTime.Parse(txtNgayCongVanDen.Text),
                    SOCV=txtSoCongVan.Text,
                    NGAYCV = (txtNgayCongVanGoc.Text == "") ?  DateTime.Now.Date : DateTime.Parse(txtNgayCongVanGoc.Text),
                    DSCQ=coquan,
                    TLVB=theloai,
                    DSDV = donvi,
                    NOIDUNG=txtNoiDung.Text,
                    BGD=lanhdao,
                    SAOGUI=txtSaoGoi.Text,
                    YKIENGQ=txtYKien.Text,
                    GHICHU=txtGhiChu.Text,
                    FileUrl=txtUrl.Text,
                    Hidden=chkHidden.Checked,
                };

                ApplicationManager.Entities.AddToCONGVANs(document);
                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadDocummentList();
                this.ClearForm();
            }
            catch (Exception ex)
            {
                this.SetError(ex.Message);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {

                if (!string.IsNullOrEmpty(txtMaCongVan.Text))
                {
                    var coquan = _dscq.FirstOrDefault(t => t.MACQ == ddlDonViGoiNhan.SelectedValue);
                    var theloai = _tlvb.FirstOrDefault(t => t.MATL == ddlTheLoai.SelectedValue);
                    var donvi = _dsdv.FirstOrDefault(t => t.MADV == ddlDonViSoan.SelectedValue);
                    var lanhdao = _bgd.FirstOrDefault(t => t.MALD == ddlLanhDao.SelectedValue);

                    var docId = grvDocumments.SelectedDataKey["SOCVD"].ToString();
                    var docs = _docs.FirstOrDefault(t => t.SOCVD == docId);
                    docs.NGAYCVD = (txtNgayCongVanDen.Text == "") ?  DateTime.Now.Date : DateTime.Parse(txtNgayCongVanDen.Text);
                    docs.SOCV = txtSoCongVan.Text;
                    docs.NGAYCV = (txtNgayCongVanGoc.Text == "") ? DateTime.Now.Date : DateTime.Parse(txtNgayCongVanGoc.Text);
                    docs.DSCQ = coquan;
                    docs.TLVB = theloai;
                    docs.DSDV = donvi;
                    docs.NOIDUNG = txtNoiDung.Text;
                    docs.SAOGUI = txtSaoGoi.Text;
                    docs.YKIENGQ = txtYKien.Text;
                    docs.GHICHU = txtGhiChu.Text;
                    docs.FileUrl = txtUrl.Text;
                    docs.Hidden = chkHidden.Checked;
                    ApplicationManager.Entities.SaveChanges();
                    this.UpdateCacheData();
                    this.LoadDocummentList();
                    this.ClearForm();
                }
                else
                {
                    this.SetError("Không tìm thấy công văn này");
                }
            }
            catch (Exception ex)
            {
                this.SetError(ex.Message);
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearForm();
        }

        private void LoadDocummentList()
        {
            grvDocumments.DataSource = _docs.OrderByDescending(t => t.NGAYCVD).ToList();
            grvDocumments.DataBind();
        }

        protected void grvDocumments_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var document = e.Row.DataItem as Data.CONGVAN;
                

                var ltCq = e.Row.Cells[2].FindControl("ltCq") as Literal;
                //var ltTl = e.Row.Cells[5].FindControl("ltTl") as Literal;
                //var ltDv = e.Row.Cells[6].FindControl("ltDv") as Literal;
                //var ltLd = e.Row.Cells[8].FindControl("ltLd") as Literal;
                var txtNoiDung = e.Row.Cells[5].FindControl("txtNoiDung") as TextBox;
                //var txtSaoGui = e.Row.Cells[9].FindControl("txtSaoGui") as TextBox;
                //var txtYKien = e.Row.Cells[10].FindControl("txtYKien") as TextBox;
                //var txtGhiChu = e.Row.Cells[11].FindControl("txtGhiChu") as TextBox;

                ltCq.Text = document.DSCQ.TENCQ;
                //ltTl.Text = document.TLVB.TENTL;
                //if (document.DSDV!=null)
                //{
                //    ltDv.Text = document.DSDV.TENDV;
                //}
                //else
                //{
                //    ltDv.Text = "";
                //}
                //ltLd.Text = document.BGD.TENLD;
                txtNoiDung.Text = document.NOIDUNG;
                //txtSaoGui.Text = document.SAOGUI;
                //txtYKien.Text = document.YKIENGQ;
                //txtGhiChu.Text = document.GHICHU;

            }
        }

        private void UpdateCacheData()
        {
            ApplicationManager.UpdateCacheData<Data.CONGVAN>(ApplicationManager.Entities.CONGVANs.Where(t => !t.Hidden));
            _docs = ApplicationManager.UpdateCacheData<Data.CONGVAN>(ApplicationManager.Entities.CONGVANs, "AdminList");
        }

        private void ClearForm()
        {
            txtMaCongVan.Text = "";
            txtNgayCongVanDen.Text = String.Format("{0:dd/MM/yyyy}", DateTime.Now.Date); 
            txtSoCongVan.Text = "";
            txtNgayCongVanGoc.Text = ""; 
            ddlDonViSoan.SelectedValue = "";
            txtNoiDung.Text = "";
            txtSaoGoi.Text = "";
            txtYKien.Text = "";
            txtGhiChu.Text = "";
            txtUrl.Text = "";
            chkHidden.Checked = true;
            ltrError.Text = string.Empty;
            txtMaCongVan.Focus();
        }

        private void SetError(string message)
        {
            message = string.IsNullOrEmpty(message) ? null : string.Format(ErrorBar, message);
            ltrError.Text = message;
        }

        protected void ddlHinhThucCapNhat_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlHinhThucCapNhat.SelectedValue == "1")
            {
                txtMaCongVan.Visible = true;
                lblMaCongVan.Visible = true;
                lblMaCongVan.Text = "Số Đến:";

                txtNgayCongVanDen.Visible = true;
                lblNgayCongVanDen.Visible = true;
                lblNgayCongVanDen.Text = "Ngày Đến:";

                txtSoCongVan.Visible = true;
                lblSoCongVan.Visible = true;
                lblSoCongVan.Text = "Số CV:";

                txtNgayCongVanGoc.Visible = true;
                lblNgayCongVan.Visible = true;
                lblNgayCongVan.Text = "Ngày CV";

                ddlDonViGoiNhan.Visible = true;
                lblDonViGoiNhan.Visible = true;
                lblDonViGoiNhan.Text = "Đơn Vị Gởi";

                ddlTheLoai.Visible = true;
                lblTheLoai.Visible = true;
                lblTheLoai.Text = "Thể Loại";

                ddlLanhDao.Visible = true;
                lblLanhDao.Visible = true;
                lblLanhDao.Text = "Trình Lãnh Đạo";

                ddlDonViSoan.Visible = false;
                lblDonViSoan.Visible = false;
                lblDonViSoan.Text = "";

                txtNoiDung.Visible = true;
                lblNoiDung.Visible = true;
                lblNoiDung.Text = "Nội Dung Công Văn";

                txtSaoGoi.Visible = true;
                lblSaoGui.Visible = true;
                lblSaoGui.Text = "Sao Gửi Đơn Vị";

                txtYKien.Visible = true;
                lblYKien.Visible = true;
                lblYKien.Text = "Ý Kiến Giải Quyết";

                txtGhiChu.Visible = true;
                lblGhiChu.Visible = true;
                lblGhiChu.Text = "Ghi Chú";

                txtUrl.Visible = true;
                chkHidden.Visible = true;
            }
            if (ddlHinhThucCapNhat.SelectedValue == "2")
            {
                txtMaCongVan.Visible = true;
                lblMaCongVan.Visible = true;
                lblMaCongVan.Text = "Số CV Đi:";

                txtNgayCongVanDen.Visible = true;
                lblNgayCongVanDen.Visible = true;
                lblNgayCongVanDen.Text = "Ngày CV:";

                txtSoCongVan.Visible = false;
                lblSoCongVan.Visible = false;
                lblSoCongVan.Text = "Số CV:";

                txtNgayCongVanGoc.Visible = false;
                lblNgayCongVan.Visible = false;
                lblNgayCongVan.Text = "Ngày CV";

                ddlDonViGoiNhan.Visible = true;
                lblDonViGoiNhan.Visible = true;
                lblDonViGoiNhan.Text = "Đơn Vị Nhận";

                ddlTheLoai.Visible = true;
                lblTheLoai.Visible = true;
                lblTheLoai.Text = "Thể Loại";

                ddlLanhDao.Visible = true;
                lblLanhDao.Visible = true;
                lblLanhDao.Text = "Lãnh Đạo Ký";

                ddlDonViSoan.Visible = true;
                lblDonViSoan.Visible = true;
                lblDonViSoan.Text = "Đơn Vị Soạn";

                txtNoiDung.Visible = true;
                lblNoiDung.Visible = true;
                lblNoiDung.Text = "Nội Dung Công Văn";

                txtSaoGoi.Visible = true;
                lblSaoGui.Visible = true;
                lblSaoGui.Text = "Sao Gửi Đơn Vị";

                txtYKien.Visible = true;
                lblYKien.Visible = true;
                lblYKien.Text = "Ý Kiến Giải Quyết";

                txtGhiChu.Visible = true;
                lblGhiChu.Visible = true;
                lblGhiChu.Text = "Ghi Chú";

                txtUrl.Visible = true;
                chkHidden.Visible = true;
            }

            if (ddlHinhThucCapNhat.SelectedValue == "3")
            {
                txtMaCongVan.Visible = true;
                lblMaCongVan.Visible = true;
                lblMaCongVan.Text = "Số CV Đi:";

                txtNgayCongVanDen.Visible = true;
                lblNgayCongVanDen.Visible = true;
                lblNgayCongVanDen.Text = "Ngày CV:";

                txtSoCongVan.Visible = false;
                lblSoCongVan.Visible = false;
                lblSoCongVan.Text = "Số CV:";

                txtNgayCongVanGoc.Visible = false;
                lblNgayCongVan.Visible = false;
                lblNgayCongVan.Text = "Ngày CV";

                ddlDonViGoiNhan.Visible = true;
                lblDonViGoiNhan.Visible = true;
                lblDonViGoiNhan.Text = "Đơn Vị Nhận";

                ddlTheLoai.Visible = true;
                lblTheLoai.Visible = true;
                lblTheLoai.Text = "Thể Loại";

                ddlLanhDao.Visible = true;
                lblLanhDao.Visible = true;
                lblLanhDao.Text = "Lãnh Đạo Ký";

                ddlDonViSoan.Visible = true;
                lblDonViSoan.Visible = true;
                lblDonViSoan.Text = "Đơn Vị Soạn";

                txtNoiDung.Visible = true;
                lblNoiDung.Visible = true;
                lblNoiDung.Text = "Nội Dung Công Văn";

                txtSaoGoi.Visible = true;
                lblSaoGui.Visible = true;
                lblSaoGui.Text = "Sao Gửi Đơn Vị";

                txtYKien.Visible = true;
                lblYKien.Visible = true;
                lblYKien.Text = "Công Văn Phúc Đáp";

                txtGhiChu.Visible = true;
                lblGhiChu.Visible = true;
                lblGhiChu.Text = "Ghi Chú";

                txtUrl.Visible = true;
                chkHidden.Visible = true;
            }

            if (ddlHinhThucCapNhat.SelectedValue == "4")
            {
                txtMaCongVan.Visible = true;
                lblMaCongVan.Visible = true;
                lblMaCongVan.Text = "Số Đến:";

                txtNgayCongVanDen.Visible = true;
                lblNgayCongVanDen.Visible = true;
                lblNgayCongVanDen.Text = "Ngày Đến:";

                txtSoCongVan.Visible = true;
                lblSoCongVan.Visible = true;
                lblSoCongVan.Text = "Số CV:";

                txtNgayCongVanGoc.Visible = true;
                lblNgayCongVan.Visible = true;
                lblNgayCongVan.Text = "Ngày CV";

                ddlDonViGoiNhan.Visible = true;
                lblDonViGoiNhan.Visible = true;
                lblDonViGoiNhan.Text = "Đơn Vị Gởi";

                ddlTheLoai.Visible = true;
                lblTheLoai.Visible = true;
                lblTheLoai.Text = "Thể Loại";

                ddlLanhDao.Visible = true;
                lblLanhDao.Visible = true;
                lblLanhDao.Text = "Trình Lãnh Đạo";

                ddlDonViSoan.Visible = false;
                lblDonViSoan.Visible = false;
                lblDonViSoan.Text = "";

                txtNoiDung.Visible = true;
                lblNoiDung.Visible = true;
                lblNoiDung.Text = "Nội Dung Công Văn";

                txtSaoGoi.Visible = true;
                lblSaoGui.Visible = true;
                lblSaoGui.Text = "Sao Gửi Đơn Vị";

                txtYKien.Visible = true;
                lblYKien.Visible = true;
                lblYKien.Text = "Ý Kiến Giải Quyết";

                txtGhiChu.Visible = true;
                lblGhiChu.Visible = true;
                lblGhiChu.Text = "Ghi Chú";

                txtUrl.Visible = true;
                chkHidden.Visible = true;
            }
        }


        protected void btnPrint_Click(object sender, EventArgs e)
        {
            //Response.Redirect("~/Officer/Internal/ShowReport.aspx");
            mdlPopup.Show();
        }

        protected void btnOk_Click(object sender, EventArgs e)
        {
            string redirectUrl = string.Empty;
            if (chkCongVanDen.Checked == true)
            {
                //Response.Redirect("~/Officer/Internal/ShowReportCongVanDen.aspx");
                redirectUrl = HostName + "/bao-mat/bao-cao-cong-van-den.aspx";
            }
            if (chkCongVanDi.Checked == true)
            {
                redirectUrl = HostName + "/bao-mat/bao-cao-cong-van-di.aspx";
            }
            if (chkCongVanNB.Checked == true)
            {
                redirectUrl = HostName + "/bao-mat/bao-cao-cong-van-noi-bo.aspx";
            }
            if (chkQuyetDinhBanNganh.Checked == true)
            {
                redirectUrl = HostName + "/bao-mat/bao-cao-quyet-dinh-ban-nganh.aspx";
            }
            Response.Redirect(redirectUrl);
        }
            

    }
}