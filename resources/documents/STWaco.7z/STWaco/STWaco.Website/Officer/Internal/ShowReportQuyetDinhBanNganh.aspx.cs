﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using STWaco.Data;
using STWaco.Website.Officer.Internal.Report;

namespace STWaco.Website.Officer.Internal
{
    public partial class ShowReportQuyetDinhBanNganh : BaseUI.OfficerPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            string redirectUrl = string.Empty;
            redirectUrl = HostName + "/bao-mat/cong-van-vien.aspx";
            Response.Redirect(redirectUrl);
        }
    }
}