﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Officer.Internal
{
    public partial class DanhSachCoQuan : BaseUI.OfficerPage
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Danh Sách Cơ Quan";
            
            if (!IsPostBack)
            {                
                this.LoadDSCQ();
            }
        }


        protected void grvDSCQ_SelectedIndexChanged(object sender, EventArgs e)
        {
            var macq = grvDSCQ.SelectedDataKey["MACQ"].ToString();
            var danhsachcq = _dscq.FirstOrDefault(t => t.MACQ == macq);

            txtMACQ.Text = danhsachcq.MACQ;
            txtTenCoQuan.Text = danhsachcq.TENCQ;
            txtDiaChi.Text = danhsachcq.DIACHI;
            txtDienThoai.Text = danhsachcq.SODT;
            txtSoFax.Text = danhsachcq.SOFAX;
            txtThuTruong.Text = danhsachcq.THUTRUONG;
            txtChucDanh.Text = danhsachcq.CHUCDANH;
            txtWebsite.Text = danhsachcq.WWW;
            txtEmail.Text = danhsachcq.EMAIL;
            txtGhiChu.Text = danhsachcq.GHICHU;
            this.SetError(null);
        }

        protected void grvDSCQ_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grvDSCQ.PageIndex = e.NewPageIndex;
        }

        protected void grvDSCQ_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadDSCQ();
        }

        protected void grvDSCQ_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            var macq = grvDSCQ.DataKeys[e.RowIndex]["MACQ"].ToString();
            var danhsachcq = _dscq.FirstOrDefault(t => t.MACQ == macq);

            ApplicationManager.Entities.DeleteObject(danhsachcq);
            ApplicationManager.Entities.SaveChanges();

            this.UpdateCacheData();
            this.LoadDSCQ();
            this.SetError(null);
            //if (!string.IsNullOrEmpty(txtID.Text) && waterconsumpId == txtID.Text)
            this.ClearForm();
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                var danhsachcq = new Data.DSCQ
                {
                    
                    MACQ=txtMACQ.Text.Trim(),
                    TENCQ=txtTenCoQuan.Text,
                    DIACHI=txtDiaChi.Text,
                    SODT=txtDienThoai.Text,
                    SOFAX=txtSoFax.Text,
                    THUTRUONG=txtThuTruong.Text,
                    CHUCDANH=txtChucDanh.Text,
                    WWW=txtWebsite.Text,
                    EMAIL=txtEmail.Text,
                    GHICHU=txtGhiChu.Text
                };

                ApplicationManager.Entities.AddToDSCQs(danhsachcq);
                ApplicationManager.Entities.SaveChanges();

                this.UpdateCacheData();
                this.LoadDSCQ();
                this.ClearForm();
            }
            catch (Exception ex)
            {
                this.SetError(ex.Message);
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            //try
            //{

                if (!string.IsNullOrEmpty(txtMACQ.Text))
                {
                    var macq = grvDSCQ.SelectedDataKey["MACQ"].ToString();
                    var danhsachcq = _dscq.FirstOrDefault(t => t.MACQ == macq);
                    
                    danhsachcq.TENCQ=txtTenCoQuan.Text;
                    danhsachcq.DIACHI=txtDiaChi.Text;
                    danhsachcq.SODT=txtDienThoai.Text;
                    danhsachcq.SOFAX=txtSoFax.Text;
                    danhsachcq.THUTRUONG=txtThuTruong.Text;
                    danhsachcq.CHUCDANH=txtChucDanh.Text;
                    danhsachcq.WWW=txtWebsite.Text;
                    danhsachcq.EMAIL=txtEmail.Text;
                    danhsachcq.GHICHU = txtGhiChu.Text;
                    ApplicationManager.Entities.SaveChanges();
                    this.UpdateCacheData();
                    this.LoadDSCQ();
                    this.ClearForm();
                }
                else
                {
                    this.SetError("Không tìm thấy cơ quan");
                }
            //}
            //catch (Exception ex)
            //{
            //    this.SetError(ex.Message);
            //}
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            this.ClearForm();
        }

        private void LoadDSCQ()
        {
            grvDSCQ.DataSource = _dscq.OrderByDescending(t => t.TENCQ).ToList();
            grvDSCQ.DataBind();
        }


        private void UpdateCacheData()
        {
            //ApplicationManager.UpdateCacheData<Data.WaterComsumption>(ApplicationManager.Entities.WaterComsumptions.Where(t => !t.Deleted));
            _dscq = ApplicationManager.UpdateCacheData<Data.DSCQ>(ApplicationManager.Entities.DSCQs, "AdminList");
        }

        private void ClearForm()
        {
            txtMACQ.Text = "";
            txtTenCoQuan.Text = "";
            txtDiaChi.Text = "";
            txtDienThoai.Text = "";
            txtSoFax.Text = "";
            txtThuTruong.Text = "";
            txtChucDanh.Text = "";
            txtWebsite.Text = "";
            txtEmail.Text = "";
            txtGhiChu.Text = "";
            txtMACQ.Focus();
        }

        private void SetError(string message)
        {
            message = string.IsNullOrEmpty(message) ? null : string.Format(ErrorBar, message);
            ltrError.Text = message;
        }
    }
}