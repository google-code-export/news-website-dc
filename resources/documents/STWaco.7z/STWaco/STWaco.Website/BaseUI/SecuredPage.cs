﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;

namespace STWaco.Website.BaseUI
{
    public class SecuredPage : BaseUI.BasePage
    {
        protected override void OnInit(EventArgs e)
        {                        
            base.OnInit(e);

            _posts = ApplicationManager.SetCacheData<Data.Post>(ApplicationManager.Entities.Posts, p => p.Approved, "SecuredList");

            SiteTitle += STWaco.Core.SEO.StringUtils.ToTitleCase(Roles.GetRolesForUser()[0]) + " :: ";
        }
    }
}