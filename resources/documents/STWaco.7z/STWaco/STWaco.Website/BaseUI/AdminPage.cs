﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Hosting;

namespace STWaco.Website.BaseUI
{
    public class AdminPage : BaseUI.SecuredPage
    {
        protected IQueryable<Data.Employee> _empl;
        protected IQueryable<Data.Grouping_Rooms> _dept;
        protected IQueryable<Data.Banner> _banners;
        
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            
            _cates = ApplicationManager.SetCacheData<Data.Category>(ApplicationManager.Entities.Categories, null, "AdminList");
            _posts = ApplicationManager.SetCacheData<Data.Post>(ApplicationManager.Entities.Posts, null, "AdminList");
            _cust = ApplicationManager.SetCacheData<Data.Customer>(ApplicationManager.Entities.Customers, null, "AdminList");
            _waterconsump = ApplicationManager.SetCacheData<Data.WaterComsumption>(ApplicationManager.Entities.WaterComsumptions, null, "AdminList");
            _dept = ApplicationManager.SetCacheData<Data.Grouping_Rooms>(ApplicationManager.Entities.Grouping_Rooms, null, "AdminList");
            _empl = ApplicationManager.SetCacheData<Data.Employee>(ApplicationManager.Entities.Employees, null, "AdminList");
            _banners = ApplicationManager.SetCacheData<Data.Banner>(ApplicationManager.Entities.Banners, null);
        }
    }
}