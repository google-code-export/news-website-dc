﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace STWaco.Website.BaseUI
{
    public class BaseMaster : System.Web.UI.MasterPage
    {
        public string HostName { get; set; }

        protected IQueryable<Data.Banner> _banners;
        
        protected override void OnInit(EventArgs e)
        {
            HostName = STWaco.Website.ApplicationManager.HostName;

            _banners = ApplicationManager.SetCacheData<Data.Banner>(ApplicationManager.Entities.Banners, null);
            
            base.OnInit(e);
        }
    }
}