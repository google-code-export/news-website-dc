﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace STWaco.Website.BaseUI
{
    public class MemberPage : BaseUI.SecuredPage
    {
        protected override void OnInit(EventArgs e)
        {                        
            base.OnInit(e);

            _posts = ApplicationManager.SetCacheData<Data.Post>(ApplicationManager.Entities.Posts, p => p.CreatedBy.Equals(User.Identity.Name), "MemberList");
        }
    }
}