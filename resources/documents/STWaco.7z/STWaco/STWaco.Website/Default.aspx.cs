﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace STWaco.Website
{
    public partial class Default1 : BaseUI.BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = "Chào Mừng Bạn Đến Với " + SiteTitle;
            
            if (!IsPostBack)
            {
                using (StreamReader reader = File.OpenText(MapPath("welcome.txt")))
                {
                    ltrContent.Text = reader.ReadToEnd();
                    ltrContent.DataBind();
                    reader.Close();
                }
            }
        }
    }
}