﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules
{
    public partial class CommentBox : BaseUI.BaseModule
    {
        public Data.Post PostItem { get; set; }

        private static Data.Post _postitem;

        protected string SlideClass { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ltrButtonHtml.Text = "<input type=\"button\" id=\"btnShowComment\" class=\"button\" value=\"Bình luận\" />";
                SlideClass = "slide-area";
            }
        }

        protected override void OnDataBinding(EventArgs e)
        {
            _postitem = PostItem;
            this.LoadPostComments();
        }

        protected void lvComments_PagePropertiesChanged(object sender, EventArgs e)
        {
            this.LoadPostComments();
        }

        private void LoadPostComments()
        {
            var comments = ApplicationManager.Entities.PostComments.Where(c => c.Post.ID == _postitem.ID);

            lvComments.DataSource = comments.OrderByDescending(c => c.CreatedOn).ToList();
            lvComments.DataBind();

            pagerComments.Visible = pagerComments.PageSize < pagerComments.TotalRowCount;
        }

        protected void btnComment_Click(object sender, EventArgs e)
        {
            ApplicationManager.Entities.AddToPostComments(new Data.PostComment
            {
                Title = Server.HtmlEncode(txtTitle.Text.Trim()),
                CreatedBy = Server.HtmlEncode(txtName.Text.Trim()),
                Content = Server.HtmlEncode(txtContent.Text.Trim()),
                CreatedOn = DateTime.Now,
                Post = _postitem
            });
            ApplicationManager.Entities.SaveChanges();

            this.LoadPostComments();

            pagerComments.SetPageProperties(0, 5, true);

            txtTitle.Text = string.Empty;
            txtName.Text = string.Empty;
            txtContent.Text = string.Empty;
        }
    }
}