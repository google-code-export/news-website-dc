﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules
{
    public partial class AccountBar : BaseUI.BaseModule
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}