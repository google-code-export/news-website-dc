﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules
{
    public partial class AdBox : BaseUI.BaseModule
    {
        public IList<Data.Banner> DataSource { get; set; }

        protected override void OnDataBinding(EventArgs e)
        {
            rptBanners.DataSource = DataSource.OrderBy(p => p.DisplayOrder == null)
                .ThenBy(p => p.DisplayOrder);
            rptBanners.DataBind();
        }

        protected void rptBanners_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
            {
                var adItem = e.Item.FindControl("adItem") as Image;

                int? height = (e.Item.DataItem as Data.Banner).Height;
                string position = (e.Item.DataItem as Data.Banner).Position;

                if (height != null) adItem.Height = Unit.Pixel(height.Value);
                adItem.Width = position.Equals("Left") ? Unit.Pixel(200) : Unit.Pixel(180);
            }
        }
    }
}