﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules
{
    public partial class SearchResults : BaseUI.BaseModule
    {
        public IList<Data.Customer> DataSource { get; set; }

        private static List<Data.Customer> SavedDataSource;

        protected override void OnDataBinding(EventArgs e)
        {
            ltrCount.Text = string.Format("({0:N0} kết quả)", DataSource.Count);

            this.LoadResultList();
        }

        protected void gvSerResults_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvSerResults.PageIndex = e.NewPageIndex;
        }

        protected void gvSerResults_PageIndexChanged(object sender, EventArgs e)
        {
            this.LoadResultList();
        }

        private void LoadResultList()
        {
            if (DataSource != null) SavedDataSource = DataSource.ToList();

            gvSerResults.DataSource = SavedDataSource;
            gvSerResults.DataBind();
        }
    }
}