﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules
{
    public partial class PostItem : BaseUI.BaseModule
    {
        public Data.Post Post { get; set; }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                imgFigure.ImageUrl = Post.Photo;

                ltrTitle.Text = Post.Title;
                ltrCreatedOn.Text = string.Format("{0:dd/MM/yyyy}", Post.CreatedOn);
                ltrDescription.Text = Post.Description;
                ltrContent.Text = Post.Content;
            }
        }
    }
}