﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules
{
    public partial class NewsBox : BaseUI.BaseModule
    {
        public IList<Data.Post> Posts { get; set; }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                rptPosts.DataSource = Posts.Where(p => p.Category.Name.Trim().ToLower().Equals("tin tức"))
                    .OrderByDescending(p => p.CreatedOn).Take(5).Select(p => new
                    {
                        p.ID, p.Title, p.Description, p.CreatedOn, p.Photo,
                        SeoUrl = string.Format("{0}/tin-tuc/{1}-{2}.aspx",
                            HostName, STWaco.Core.SEO.StringUtils.RemoveUnicodeMarks(p.Title), p.ID)
                    }).ToList();
                rptPosts.DataBind();
            }
        }
    }
}