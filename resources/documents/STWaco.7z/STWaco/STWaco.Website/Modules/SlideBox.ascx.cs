﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules
{
    public partial class SlideBox : BaseUI.BaseModule
    {
        public IList<Data.Slide> DataSource { get; set; }

        protected override void OnDataBinding(EventArgs e)
        {
            rptSlides.DataSource = DataSource;
            rptSlides.DataBind();
        }
    }
}