﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace STWaco.Website.Modules
{
    public partial class FileSelector : BaseUI.BaseModule
    {
        public string DefaultPath { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.LoadFiles();
            }
        }

        protected void upFile_FileValidating(object sender, CuteWebUI.UploaderEventArgs args)
        {
            try
            {
                string prefix = string.Format("{0:yyyyMMddHHmmss}", DateTime.Now);
                string fileName = Path.GetFileName(args.FileName);
                string filePath = Server.MapPath(DefaultPath.Replace(HostName, "~"));
                string deepPath = Path.GetExtension(args.FileName).Replace(".", "");

                string savePath = string.Format("{0}{1}/{2}_{3}", filePath, deepPath, prefix, fileName);

                args.MoveTo(savePath);
            }
            catch (Exception)
            {

            }
        }

        protected void btnLoadFiles_Click(object sender, EventArgs e)
        {
            this.LoadFiles();
        }

        protected void btnDeleteFile_Click(object sender, EventArgs e)
        {
            var filePath = Server.MapPath(((LinkButton)sender).CommandArgument.ToString().Replace(HostName, "~"));
            var fileInfo = new FileInfo(filePath);

            if (fileInfo.Exists) fileInfo.Delete();

            this.LoadFiles();
        }

        protected void lvFiles_DataBound(object sender, EventArgs e)
        {
            if (pagerFiles != null)
                pagerFiles.Visible = pagerFiles.PageSize < pagerFiles.TotalRowCount;
        }

        protected void lvFiles_PagePropertiesChanged(object sender, EventArgs e)
        {
            this.LoadFiles();
        }

        private void LoadFiles()
        {
            string[] acceptedExtensions = new[] { ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx" };

            string dirPath = Server.MapPath(DefaultPath.Replace(HostName, "~"));

            var photos = new DirectoryInfo(dirPath).GetFiles("*", SearchOption.AllDirectories)
                .Where(f => acceptedExtensions.Contains(f.Extension.ToLower()))
                .Select(f => new
                {
                    Name = f.Name,
                    Path = string.Format("{0}{1}/{2}", DefaultPath, f.Extension.Replace(".", ""), f.Name).ToLower(),
                    TypePath = string.Format("{0}/images/icons/{1}_48.png", HostName, f.Extension.Replace(".", "")),
                    Description = string.Format("Tệp: {0} | Kích thước: {1:N1}KB | Tạo: {2:dd/MM/yyyy HH:mm:ss}", f.Name, f.Length / 1024f, f.CreationTime),
                    Size = string.Format("{0:N1}KB", f.Length / 1024f),
                    CreatedOn = f.CreationTime
                }).OrderByDescending(a => a.CreatedOn).ToList();

            lvFiles.DataSource = photos;
            lvFiles.DataBind();
        }
    }
}