﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace STWaco.Website.Modules
{
    public partial class PhotoSelector : BaseUI.BaseModule
    {
        public string DefaultPath { get; set; }

        public string IdealPhotoSize { get; set; }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.LoadPhotos();
            }
        }

        protected void upPhoto_FileValidating(object sender, CuteWebUI.UploaderEventArgs args)
        {
            try
            {
                string prefix = string.Format("{0:yyyyMMddHHmmss}", DateTime.Now);                
                string fileName = Path.GetFileName(args.FileName);
                string filePath = Server.MapPath(DefaultPath.Replace(HostName, "~"));

                string savePath = string.Format("{0}{1}_{2}", filePath, prefix, fileName);
                
                args.MoveTo(savePath);
            }
            catch (Exception)
            {
                
            }
        }

        protected void btnLoadPhotos_Click(object sender, EventArgs e)
        {
            this.LoadPhotos();
        }

        protected void btnDeletePhoto_Click(object sender, EventArgs e)
        {
            var filePath = Server.MapPath(((LinkButton)sender).CommandArgument.ToString().Replace(HostName, "~"));
            var fileInfo = new FileInfo(filePath);

            if (fileInfo.Exists) fileInfo.Delete();

            this.LoadPhotos();
        }

        protected void lvPhotos_DataBound(object sender, EventArgs e)
        {
            //var pagerPhotos = lvPhotos.FindControl("pagerPhotos") as DataPager;
            if (pagerPhotos != null)
                pagerPhotos.Visible = pagerPhotos.PageSize < pagerPhotos.TotalRowCount;
        }        

        protected void lvPhotos_PagePropertiesChanged(object sender, EventArgs e)
        {
            this.LoadPhotos();
        }

        private void LoadPhotos()
        {
            string[] acceptedExtensions = new[] { ".jpg", ".gif", ".png" };
            
            string dirPath = Server.MapPath(DefaultPath.Replace(HostName, "~"));

            var photos = new DirectoryInfo(dirPath).GetFiles("*", SearchOption.AllDirectories)
                .Where(f => acceptedExtensions.Contains(f.Extension.ToLower()))
                .Select(f => new
                {
                    Name = f.Name,
                    Path = (DefaultPath + f.Name).ToLower(),
                    Description = string.Format("Tệp: {0} | Kích thước: {1:N1}KB | Tạo: {2:dd/MM/yyyy HH:mm:ss}", f.Name, f.Length / 1024f, f.CreationTime),
                    Size = string.Format("{0:N1}KB", f.Length / 1024f),
                    CreatedOn = f.CreationTime
                }).OrderByDescending(a => a.CreatedOn).ToList();

            lvPhotos.DataSource = photos;
            lvPhotos.DataBind();
        }
    }
}