﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules
{
    public partial class WaterInfoDetails : BaseUI.BaseModule
    {        
        public IList<Data.WaterComsumption> DataSourceWaterConsump { get; set; }

        private static List<Data.WaterComsumption> SavedDataSourceWaterConsump;
        
        protected override void OnDataBinding(EventArgs e)
        {
            LoadWaterCumsumptionList();
        }

        protected void gvWaterInfoDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvWaterInfoDetails.PageIndex = e.NewPageIndex;
        }

        protected void gvWaterInfoDetails_PageIndexChanged(object sender, EventArgs e)
        {
            LoadWaterCumsumptionList();
        }

        private void LoadWaterCumsumptionList()
        {
            if (DataSourceWaterConsump != null)
            {
                SavedDataSourceWaterConsump = DataSourceWaterConsump.OrderByDescending(t => t.CreatedOn).ToList();
            }
            
            gvWaterInfoDetails.DataSource = SavedDataSourceWaterConsump;
            gvWaterInfoDetails.DataBind();
        }
    }
}