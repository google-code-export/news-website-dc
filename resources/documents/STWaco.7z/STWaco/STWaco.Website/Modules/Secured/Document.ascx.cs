﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules.Secured
{
    public partial class Document : BaseUI.MemberModule
    {
        public IList<Data.CONGVAN> DataSourceCongVan { get; set; }
        private string Url { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected override void OnDataBinding(EventArgs e)
        {

            LoadDocumentList();
        }

        protected void gvDocument_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gvDocument.PageIndex = e.NewPageIndex;
        }

        protected void gvDocument_PageIndexChanged(object sender, EventArgs e)
        {
            LoadDocumentList();
        }

        private void LoadDocumentList()
        {
            gvDocument.DataSource = DataSourceCongVan.OrderByDescending(t => t.NGAYCVD).ToList();
            gvDocument.DataBind();
        }

        protected void gvDocument_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                var document = e.Row.DataItem as Data.CONGVAN;
                var ltCq = e.Row.Cells[2].FindControl("ltCq") as Literal;
                var hlUrl = e.Row.Cells[4].FindControl("hlUrl") as HyperLink;
                ltCq.Text = document.DSCQ.TENCQ;
                hlUrl.NavigateUrl = document.FileUrl;
                hlUrl.Text = "Xem";
            }
        }

    }
}