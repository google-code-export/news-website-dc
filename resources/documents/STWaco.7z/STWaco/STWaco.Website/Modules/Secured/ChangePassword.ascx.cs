﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules.Secured
{
    public partial class ChangePassword : BaseUI.MemberModule
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!(IsPostBack))
            {
                changePassword.ChangePasswordFailureText = string.Format(ErrorBar, "Thay đổi không thành công. Vui lòng kiểm tra lại.");
            }
        }
    }
}