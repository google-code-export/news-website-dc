﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules.Secured
{
    public partial class InternalNewsByMonths : BaseUI.SecuredModule
    {
        public IList<Data.Post> Posts { get; set; }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                rptPostsByMonth.DataSource = Posts.Where(p => p.Category.Name.Trim().ToLower().Equals("thông tin nội bộ"))
                    .GroupBy(p => new { p.CreatedOn.Month, p.CreatedOn.Year })
                    .Select(g => new { g.First().CreatedOn })
                    .OrderByDescending(g => g.CreatedOn).Take(10).ToList();
                rptPostsByMonth.DataBind();
            }
        }
    }
}