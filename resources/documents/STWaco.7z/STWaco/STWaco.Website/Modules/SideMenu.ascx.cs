﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules
{
    public partial class SideMenu : BaseUI.BaseModule
    {
        public IList<Data.Post> Posts { get; set; }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            this.HighlightActiveMenu();
            
            if (!IsPostBack)
            {                
                this.LoadProductsAndServicesList();
                this.LoadPostsByMonthsList();
            }
        }

        private void HighlightActiveMenu()
        {
            var links = (from c in this.Controls.Cast<Control>() where c.GetType() == typeof(HyperLink) select c)
                .ToList().ConvertAll<HyperLink>(l => (HyperLink)l);
            var activeLink = (from l in links where l.CssClass == (SiteMap.CurrentNode != null ? SiteMap.CurrentNode.Description : "") select l)
                .FirstOrDefault();
            if (activeLink != null) { activeLink.CssClass += " parent-active"; }
        }

        private void LoadProductsAndServicesList()
        {
            rptPro_Sev.DataSource = Posts.Where(p => p.Category.Name.Trim().ToLower().Equals("sản phẩm & dịch vụ"))
                    .OrderByDescending(p => p.CreatedOn).Take(10).Select(p => new
                    {
                        p.ID, p.Title,
                        SeoUrl = string.Format("{0}/san-pham-dich-vu/{1}-{2}.aspx",
                            HostName, STWaco.Core.SEO.StringUtils.RemoveUnicodeMarks(p.Title), p.ID)
                    }).ToList();
            rptPro_Sev.DataBind();
        }

        private void LoadPostsByMonthsList()
        {
            rptPostsByMonth.DataSource = Posts.Where(p => p.Category.Name.Trim().ToLower().Equals("tin tức"))
                .GroupBy(p => new { p.CreatedOn.Month, p.CreatedOn.Year })
                .Select(g => new { g.First().CreatedOn })
                .OrderByDescending(g => g.CreatedOn).Take(5).ToList();
            rptPostsByMonth.DataBind();
        }
    }
}