﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules
{
    public partial class CategoryList : BaseUI.BaseModule
    {
        public IList<Data.Post> Posts { get; set; }

        public string CategoryDir { get; set; }

        public string SecuredPreffix { get; set; }
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.LoadPosts();
            }
        }

        // this one is used to url rewrite datapager links
        protected void lvPosts_DataBound(object sender, EventArgs e)
        {
            bool moreThanOnePage = pagerPosts.PageSize < pagerPosts.TotalRowCount;

            pagerPosts.Visible = moreThanOnePage;

            // this check is important to avoid touching the Hyperlinks if the Pager doesn't configured to use Query string Field
            if (!string.IsNullOrEmpty(pagerPosts.QueryStringField) && moreThanOnePage)
            {
                foreach (DataPagerFieldItem Pitem in pagerPosts.Controls)
                {
                    foreach (Control c in Pitem.Controls)
                    {
                        if (c is HyperLink)
                        {
                            HyperLink tmp = c as HyperLink;

                            // check if the navigate url contains 'page' query string
                            if (tmp.NavigateUrl.IndexOf(pagerPosts.QueryStringField + "=") != -1)
                            {
                                string pageIndexString = tmp.NavigateUrl.Split(new string[]
                                { pagerPosts.QueryStringField + "=" }, StringSplitOptions.RemoveEmptyEntries)[1];

                                // check if current url contains 'scope' query string
                                string timescope = Request.QueryString["scope"];
                                string monthString = string.IsNullOrEmpty(timescope) ? "" : "-thang-";
                                timescope = string.IsNullOrEmpty(timescope) ? "" : timescope.Replace(' ', '+');

                                // don't write page index for the first page
                                if (pageIndexString.Equals("1"))
                                {
                                    tmp.NavigateUrl = string.Format("{0}{1}/danh-muc-{2}{3}{4}.aspx",
                                        HostName, SecuredPreffix, CategoryDir, monthString, timescope);
                                }
                                else
                                {
                                    tmp.NavigateUrl = string.Format("{0}{1}/danh-muc-{2}{3}{4}/trang-{5}.aspx",
                                        HostName, SecuredPreffix, CategoryDir, monthString, timescope, pageIndexString);
                                }
                            }
                        }
                    }
                }
            }
        }

        protected void lvPosts_PagePropertiesChanged(object sender, EventArgs e)
        {
            this.LoadPosts();
        }

        private void LoadPosts()
        {
            lvPosts.DataSource = Posts.OrderByDescending(p => p.CreatedOn)
                    .Select(p => new
                    {
                        p.ID,
                        p.Title,
                        p.Description,
                        p.Photo,
                        p.CreatedOn,
                        SeoUrl = string.Format("{0}{1}/{2}/{3}-{4}.aspx", HostName, SecuredPreffix, CategoryDir,
                            STWaco.Core.SEO.StringUtils.RemoveUnicodeMarks(p.Title), p.ID)
                    }).ToList();
            lvPosts.DataBind();
        }
    }
}