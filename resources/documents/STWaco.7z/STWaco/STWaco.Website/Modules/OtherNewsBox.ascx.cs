﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Modules
{
    public partial class OtherNewsBox : BaseUI.BaseModule
    {
        public IList<Data.Post> Posts { get; set; }

        public string CategoryDir { get; set; }

        public string SecuredPreffix { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                rptPosts.DataSource = Posts.OrderByDescending(p => p.CreatedOn).Take(5).Select(p => new
                    {
                        p.ID,
                        p.Title,
                        p.Description,
                        p.CreatedOn,
                        SeoUrl = string.Format("{0}{1}/{2}/{3}-{4}.aspx",
                            HostName, SecuredPreffix, CategoryDir,
                            STWaco.Core.SEO.StringUtils.RemoveUnicodeMarks(p.Title), p.ID)
                    }).ToList();
                rptPosts.DataBind();
            }
        }
    }
}