﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Member
{
    public partial class Member : BaseUI.MemberMaster
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                this.LoadHeaderMenu();
            }
        }

        private void LoadHeaderMenu()
        {
            _HeaderMenu.Posts = ApplicationManager.SetCacheData<Data.Post>(ApplicationManager.Entities.Posts, p => p.Approved).ToList();
            _HeaderMenu.DataBind();
        }
    }
}