﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website.Member.Internal
{
    public partial class Document : BaseUI.MemberPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Xem Công Văn";

            this.LoadDocumentList();
        }

        private void LoadDocumentList()
        {
            ucDocument.DataSourceCongVan = _docs.OrderByDescending(t => t.NGAYCVD).ToList();
            ucDocument.DataBind();
        }


    }
}