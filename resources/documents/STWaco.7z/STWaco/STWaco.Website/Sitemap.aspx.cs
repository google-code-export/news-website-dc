﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website
{
    public partial class Sitemap : BaseUI.BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Sơ Đồ Web";
            
            if (!IsPostBack)
            {
                this.LoadProductsAndServicesList();
                this.LoadPostsByMonthsList();
            }
        }

        private void LoadProductsAndServicesList()
        {
            var posts = _posts.Where(p => p.Category.Name.Trim().ToLower().Equals("sản phẩm & dịch vụ"))
                    .OrderByDescending(p => p.CreatedOn).Take(10);
            
            var node = siteMap.FindNode("product_service");

            foreach (var post in posts)
            {
                node.ChildNodes.Add(new TreeNode
                {
                    Text = post.Title,
                    NavigateUrl = string.Format("{0}/san-pham-dich-vu/{1}-{2}.aspx",
                        HostName, STWaco.Core.SEO.StringUtils.RemoveUnicodeMarks(post.Title), post.ID)
                });
            }

            siteMap.DataBind();
        }

        private void LoadPostsByMonthsList()
        {
            var random = _posts.Where(p => p.Category.Name.Trim().ToLower().Equals("tin tức"))
                .GroupBy(p => new { p.CreatedOn.Month, p.CreatedOn.Year, p.CreatedBy })
                .Select(g => new { g.First().CreatedOn, g.First().CreatedBy })
                .OrderByDescending(g => g.CreatedOn).ToList();

            var node = siteMap.FindNode("news");

            foreach (var item in random)
            {
                node.ChildNodes.Add(new TreeNode
                {
                    Text = string.Format("Tin tức Tháng {0:MM/yyyy}", item.CreatedOn),
                    NavigateUrl = string.Format(HostName + "/danh-muc-tin-tuc-thang-{0:MM+yyyy}.aspx", item.CreatedOn)
                });
            }

            siteMap.DataBind();
        }
    }
}