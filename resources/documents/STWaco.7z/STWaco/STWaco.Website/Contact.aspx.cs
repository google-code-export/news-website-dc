﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace STWaco.Website
{
    public partial class Contact : BaseUI.BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.Title = SiteTitle + "Liên Hệ";
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            var contact = new Data.Contact
            {
                Name = Server.HtmlEncode(txtName.Text.Trim()),
                Email = txtEmail.Text,
                Phone = txtPhone.Text.Trim(),
                Company = Server.HtmlEncode(txtCompany.Text.Trim()),
                Website = txtWebsite.Text,
                Message = Server.HtmlEncode(txtMessage.Text.Trim()),
                CreatedOn = DateTime.Now
            };

            ApplicationManager.Entities.AddToContacts(contact);
            ApplicationManager.Entities.SaveChanges();

            this.UpdateCacheData();

            ltrDone.Text = string.Format(InfoBar, "Tin nhắn đã được gởi");

            txtName.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtPhone.Text = string.Empty;
            txtCompany.Text = string.Empty;
            txtWebsite.Text = string.Empty;
            txtMessage.Text = string.Empty;
        }

        private void UpdateCacheData()
        {
            _contacts = ApplicationManager.UpdateCacheData<Data.Contact>(ApplicationManager.Entities.Contacts);
        }
    }
}