﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace STWaco.Data
{
    public class ListOption
    {
        public object Value { get; set; }

        public string Text { get; set; }
    }
}
