﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace STWaco.Data
{
    partial class STWacoEntities
    {
        public IEnumerable<CongVanInfo> GetCongVanInfo(DateTime ngaybatdau,DateTime ngayketthuc, string subMaCV)
        {
            var query = from a in this.CONGVANs
                        where a.NGAYCVD >= ngaybatdau && a.NGAYCVD <= ngayketthuc && a.SOCVD.Substring(3, 2) == subMaCV
                        select new CongVanInfo
                        {
                            Socvd=a.SOCVD,
                            Ngaycvd =(DateTime)a.NGAYCVD,
                            Socv=a.SOCV,
                            Ngaycv = (DateTime)a.NGAYCV,
                            Coquan=a.DSCQ.TENCQ,
                            Theloai=a.TLVB.TENTL,
                            Donvi = a.DSDV.TENDV,
                            Noidung=a.NOIDUNG,
                            Lanhdao=a.BGD.TENLD,
                            Saogui=a.SAOGUI,
                            Ykien=a.YKIENGQ,
                            Ghichu=a.GHICHU
                        };

            return query.ToArray();
        }
        public class CongVanInfo
        {
            public string Socvd { get; set; }
            public DateTime Ngaycvd { get; set; }
            public string Socv { get; set; }
            public DateTime Ngaycv { get; set; }
            public string Coquan { get; set; }
            public string Theloai { get; set; }
            public string Donvi { get; set; }
            public string Noidung { get; set; }
            public string Lanhdao { get; set; }
            public string Saogui { get; set; }
            public string Ykien { get; set; }
            public string Ghichu { get; set; }
        }
    }
}
