﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;
using System.Text;
using System.Xml;

namespace STWaco.Core.Utils
{
    public class Counter
    {
        private static XElement _counter;

        private static string _xmlPath;

        public static void Init(string xmlPath)
        {
            _xmlPath = xmlPath;
            _counter = XElement.Load(_xmlPath);
        }
        
        public static void WriteToHit()
        {
            _counter.SetElementValue("hit", ReadHit() + 1);
        }

        public static void WriteToToday()
        {
            var date = (from d in _counter.Element("dates").Elements("date")
                        where DateTime.Parse(d.Attribute("key").Value) == DateTime.Today
                        select d).FirstOrDefault();
            
            if (date == null)
            {
                var newDate = new XElement("date",
                    new XAttribute("key", string.Format("{0:dd/MM/yyyy}", DateTime.Today)), 1);
                
                _counter.Element("dates").AddFirst(newDate);                
            }
            else
            {
                date.SetValue(ReadToday() + 1);
            }

            _counter.Save(_xmlPath);
        }

        public static int ReadHit()
        {
            return int.Parse(_counter.Element("hit").Value);
        }

        public static int ReadToday()
        {
            var date = (from d in _counter.Element("dates").Elements("date")
                        where DateTime.Parse(d.Attribute("key").Value) == DateTime.Today
                        select d).FirstOrDefault();
            
            return int.Parse(date.Value);
        }
    }
}
