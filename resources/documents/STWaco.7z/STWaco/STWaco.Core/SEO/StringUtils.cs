﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;

namespace STWaco.Core.SEO
{
    public class StringUtils
    {
        public static string RemoveUnicodeMarks(string accented)
        {
            accented = accented.Length > 50 ? accented.Substring(0, 50) : accented;

            string[] splitted = accented.Split("~!@#$%^&*()_+ '\",.?/`“”-–".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            accented = string.Join("-", splitted).ToLower();
            
            Regex regex = new Regex(@"\p{IsCombiningDiacriticalMarks}+");
            string strFormD = accented.Normalize(System.Text.NormalizationForm.FormD);

            return regex.Replace(strFormD, String.Empty).Replace('\u0111', 'd').Replace('\u0110', 'D');
        }

        public static string ToTitleCase(string input)
        {
            var tifo = new CultureInfo("vi-VN", false).TextInfo;
            return tifo.ToTitleCase(input);
        }
    }
}